<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MPengguna extends Model
{
    use HasFactory;
    protected $table = 'users';
    protected $primaryKey = 'id_user';
    protected $guard = 'id_user';
    protected $fillable = [
        'username',
        'password',
        'password2',
        'nama',
        'telp',
        'status',
        'is_active'
    ];
}
