<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class MBayarPrivate extends Model
{
    use HasFactory;
    protected $table = 'tb_bayar_private';
    protected $primaryKey = 'id_bayar_private';
    protected $guard = 'id_bayar_private';
    protected $fillable = [
        'tgl_bayar',
        'no_kwitansi',
        'jumlah_pertemuan',
        'id_pelajar',
        'id_bimbel_private',
        'id_pengguna',
    ];

    public function pelajar()
    {
        return $this->belongsTo(MPelajar::class, 'id_pelajar');
    }
    public function private()
    {
        return $this->belongsTo(MBimbelPrivate::class, 'id_bimbel_private', 'id_bimbel_private');
    }
    public function pertemuan()
    {
        return $this->hasMany(MPertemuan::class, 'id_bayar', 'id_bayar_private');
    }
    public function pengguna()
    {
        return $this->belongsTo(MPengguna::class, 'id_pengguna', 'id_user');
    }

    public static function generateKwitansi()
    {
        $lastReguler = self::orderBy('no_kwitansi', 'desc')->first();
        if (!$lastReguler) {
            // Jika belum ada data, mulai dari R0001
            return 'R0001';
        }
        $lastNumber = intval(substr($lastReguler->no_kwitansi, 1)); // Mengambil angka setelah karakter 'R'
        $nextNumber = $lastNumber + 1;
        $digits = strlen($nextNumber); // Hitung panjang digit
        return ('P' . str_pad($nextNumber, $digits > 4 ? $digits : 4, '0', STR_PAD_LEFT));
    }
}
