<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MBimbelPrivate extends Model
{
    use HasFactory;
    protected $table = 'tb_bimbel_private';
    protected $primaryKey = 'id_bimbel_private';
    protected $guard = 'id_bimbel_private';
    protected $fillable = [
        'paket_siswa',
        'tingkat_sekolah',
        'biaya',
        'jumlah_pertemuan',
    ];
}
