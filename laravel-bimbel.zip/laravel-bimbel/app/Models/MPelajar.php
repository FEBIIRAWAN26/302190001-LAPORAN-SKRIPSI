<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MPelajar extends Model
{
    use HasFactory;
    protected $table = 'tb_pelajar';
    protected $primaryKey = 'id_pelajar';
    protected $guard = 'id_pelajar';
    protected $fillable = [
        'nama',
        'kelas',
        // 'nis',
        'jk',
        'telp',
        'alamat',
    ];
}
