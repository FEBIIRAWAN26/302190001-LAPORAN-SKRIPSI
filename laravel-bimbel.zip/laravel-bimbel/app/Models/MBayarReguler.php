<?php

namespace App\Models;

use DB;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class MBayarReguler extends Model
{
    use HasFactory;
    protected $table = 'tb_bayar_reguler';
    protected $primaryKey = 'id_bayar_reguler';
    protected $guard = 'id_bayar_reguler';
    protected $fillable = [
        'tgl_bayar',
        'no_kwitansi',
        'id_pelajar',
        'id_bimbel_reguler',
        'periode_awal',
        'id_pengguna'
    ];

    public function pelajar()
    {
        return $this->belongsTo(MPelajar::class, 'id_pelajar');
    }
    public function reguler()
    {
        return $this->belongsTo(MBimbelReguler::class, 'id_bimbel_reguler');
    }
    public function pengguna()
    {
        return $this->belongsTo(MPengguna::class, 'id_pengguna', 'id_user');
    }

    public static function generateKwitansi()
    {
        $lastReguler = self::orderBy('no_kwitansi', 'desc')->first();

        if (!$lastReguler) {
            // Jika belum ada data, mulai dari R0001
            return 'R0001';
        }

        $lastNumber = intval(substr($lastReguler->no_kwitansi, 1)); // Mengambil angka setelah karakter 'R'
        $nextNumber = $lastNumber + 1;

        $digits = strlen($nextNumber); // Hitung panjang digit
        return ('R' . str_pad($nextNumber, $digits > 4 ? $digits : 4, '0', STR_PAD_LEFT));
    }
}
