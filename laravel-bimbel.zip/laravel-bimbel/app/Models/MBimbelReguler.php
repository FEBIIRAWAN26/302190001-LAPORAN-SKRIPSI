<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MBimbelReguler extends Model
{
    use HasFactory;
    protected $table = 'tb_bimbel_reguler';
    protected $primaryKey = 'id_bimbel_reguler';
    protected $guard = 'id_bimbel_reguler';
    protected $fillable = [
        'kelas',
        'biaya',
        'jumlah_pertemuan',
    ];
}
