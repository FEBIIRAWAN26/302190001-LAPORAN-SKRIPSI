<?php

namespace App\View\Components;

use Illuminate\View\Component;

class Notif extends Component
{
    /**
     * Create a new component instance.
     *
     * @return void
     */
    public $pesan;
    public $cek;
    public function __construct($pesan = 'lolos', $cek = 'ga ada')
    {
        $this->pesan = $pesan;
        $this->cek = $cek;
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|\Closure|string
     */
    public function render()
    {
        // dd('ok');
        return view('components.notif', [
            'pesan' => $this->pesan,
            'cek' => $this->cek,
        ]);
    }
}
