<?php

namespace App\Http\Controllers;

use App\Models\MBayarPrivate;
use App\Models\MBimbelPrivate;
use App\Models\MPelajar;
use App\Models\MPertemuan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CBayarPrivate extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = [
            'title' => 'Pembayaran Bimbel Private',
            'data' =>  MBayarPrivate::with('private', 'pelajar')->get(),
            'pelajar' =>  MPelajar::all(),
            'private' =>  MBimbelPrivate::all(),
            // 'data' => MBayarPrivate::all(),
        ];
        // dd(MBayarPrivate::with('pelajar', 'private')->get());
        return view('home.bayarPrivate.bayarPrivate', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validasi = $request->validate([
            'tgl_bayar' => 'required|date',
            // 'no_kwitansi' => 'required|unique:tb_bayar_private,no_kwitansi',
            'jumlah_pertemuan' => 'required|numeric|digits:1',
            'id_pelajar' => 'required|numeric',
            'id_bimbel_private' => 'required|numeric',
        ]);
        $validasi['no_kwitansi'] = MBayarPrivate::generateKwitansi();
        $validasi['id_pengguna'] = auth()->user()->id_user;
        MBayarPrivate::create($validasi);
        return redirect('/pembayaran-private')->with('pesan', 'Data pembayaran private berhasil di tambah');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\MBayarPrivate  $mBayarPrivate
     * @return \Illuminate\Http\Response
     */
    public function show(MBayarPrivate $mBayarPrivate)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\MBayarPrivate  $mBayarPrivate
     * @return \Illuminate\Http\Response
     */
    public function edit(MBayarPrivate $mBayarPrivate)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\MBayarPrivate  $mBayarPrivate
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, MBayarPrivate $pembayaran_private)
    {
        // dd(auth()->user());
        $request->validate(['id' => 'required']);
        $validasi = $request->validate([
            'tgl_bayar' => 'required|date',
            // 'no_kwitansi' => 'required|unique:tb_bayar_private,no_kwitansi,' . $request->id . ',id_bayar_private',
            'jumlah_pertemuan' => 'required|numeric|digits:1',
            'id_pelajar' => 'required|numeric',
            'id_bimbel_private' => 'required|numeric',
        ]);
        $validasi['id_pengguna'] = auth()->user()->id_user;
        MBayarPrivate::where('id_bayar_private', $request->id)->update($validasi);

        return redirect('/pembayaran-private')->with('pesan', 'Data pembayaran private berhasil di update');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\MBayarPrivate  $mBayarPrivate
     * @return \Illuminate\Http\Response
     */
    public function destroy(MBayarPrivate $pembayaran_private)
    {
        // dd();
        $hapus = MBayarPrivate::findOrFail($pembayaran_private->id_bayar_private);
        $hapus->pertemuan()->delete();
        $hapus->delete();
        return redirect('/pembayaran-private')->with('pesan', 'Data pembayaran private berhasil di hapus');
    }
    public function pertemuan(MBayarPrivate $id)
    {
        $data = [
            'title' => 'Pertemuan Bimbel Private',
            'data' => MBayarPrivate::with('pelajar')->where('id_bayar_private', $id->id_bayar_private)->first(),
            // 'pertemuan' => MPertemuan::all(),
            'pertemuan' => MPertemuan::where('id_bayar', $id->id_bayar_private)->where('ket', '=', 'P')->get(),
        ];
        return view('home.bayarPrivate.pertemuanPrivate', $data);
    }
    public function pertemuanCreate($id)
    {
        // dd($id);
        $data = [
            'tgl' => date('Y-m-d'),
            'id_bayar' => $id,
            'ket' => 'P',
        ];
        // MBayarPrivate::create($data);
        $dataTambah = DB::table('tb_pertemuan')->insert($data);
        // return redirect("/pembayaran-private/pertemuan/$id")->with('pesan', 'Data pertemuan private berhasil di tambah');
        return response()->json([
            'result' => true,
            'message' => 'Data berhasil ditambah',
            'data' => $dataTambah,
            'no' => count(MPertemuan::where('id_bayar', $id)->where('ket', '=', 'P')->get()) + 1,
        ], 200);
    }
    public function pertemuanDelete($id)
    {
        // dd('masukk');
        DB::table('tb_pertemuan')->where('id_pertemuan', request()->id_pertemuan)->delete();
        // return redirect("/pembayaran-private/pertemuan/$id")->with('pesan', 'Data pertemuan private berhasil di hapus');
        return response()->json([
            'result' => true,
            'message' => 'Data berhasil dihapus'
        ], 200);
    }

    public function print(Request $request)
    {
        // dd($request->all());
        $print = MBayarPrivate::query();
        if ($request->awal)
            $print->whereDate('tgl_bayar', '>=', $request->awal);

        if ($request->akhir)
            $print->whereDate('tgl_bayar', '<=', $request->akhir);
        $print = $print->with('pelajar', 'private', 'pertemuan')->orderBy('tgl_bayar', 'DESC')->get();
        // dd($print);
        $data = [
            'title' => 'Print Pembayaran Bimbel Private',
            'data' => $print,
        ];
        return view('home.bayarPrivate.bayarPrivatePrint', $data);
    }

    public function kwitansi(MBayarPrivate $id)
    {
        // echo MBayarPrivate::with('pelajar')->where('id_bayar_private', $id->id_bayar_privates);
        // die;
        // dd(MBayarPrivate::with('pelajar', 'private')->find($id->id_bayar_private));
        $data = [
            'title' => "Bimbel Private No. Kwitansi $id->no_kwitansi",
            'data' => MBayarPrivate::with('pelajar', 'private', 'pengguna')->find($id->id_bayar_private),
            'jenis' => 'Biaya Private',
        ];
        return view('home.bayarPrivate.bayarPrivateKwintansi', $data);
    }
}
