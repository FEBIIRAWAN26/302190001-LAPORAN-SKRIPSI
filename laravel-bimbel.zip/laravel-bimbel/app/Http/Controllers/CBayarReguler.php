<?php

namespace App\Http\Controllers;

use App\Models\MPelajar;
use Illuminate\Http\Request;
use App\Models\MBayarReguler;
use App\Models\MBimbelReguler;
use Illuminate\Support\Facades\DB;

class CBayarReguler extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = [
            'title' => 'Pembayaran Bimbel Reguler',
            // 'data' => MBayarReguler::with('pelajar', 'reguler')->get(),
            'data' => DB::table('tb_bayar_reguler as br')->select('br.id_bayar_reguler', 'br.tgl_bayar', 'br.no_kwitansi', 'br.periode_awal', 'p.nama', 'bir.biaya', 'bir.id_bimbel_reguler', 'p.id_pelajar')->join('tb_pelajar as p', 'br.id_pelajar', '=', 'p.id_pelajar')->join('tb_bimbel_reguler as bir', 'bir.id_bimbel_reguler', '=', 'br.id_bimbel_reguler')->get(),
            'pelajar' =>  MPelajar::all(),
            'reguler' =>  MBimbelReguler::all(),
            // 'data' => MBayarPrivate::all(),
        ];
        // dd(DB::table('tb_bayar_reguler as br')->select('br.*', 'p.nama', 'bir.*')->join('tb_pelajar as p', 'br.id_pelajar', '=', 'p.id_pelajar')->join('tb_bimbel_reguler as bir', 'bir.id_bimbel_reguler', '=', 'br.id_bimbel_reguler')->get());
        return view('home.bayarReguler.bayarReguler', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validasi = $request->validate([
            'tgl_bayar' => 'required|date',
            // 'no_kwitansi' => 'required|unique:tb_bayar_reguler,no_kwitansi',
            'periode_awal' => 'required|date',
            'id_pelajar' => 'required|numeric',
            'id_bimbel_reguler' => 'required|numeric',
        ]);
        $validasi['no_kwitansi'] = MBayarReguler::generateKwitansi();
        $validasi['id_pengguna'] = auth()->user()->id_user;
        MBayarReguler::create($validasi);

        return redirect('/pembayaran-reguler')->with('pesan', 'Data pembayaran reguler berhasil di tambah');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\MBayarReguler  $mBayarReguler
     * @return \Illuminate\Http\Response
     */
    public function show(MBayarReguler $mBayarReguler)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\MBayarReguler  $mBayarReguler
     * @return \Illuminate\Http\Response
     */
    public function edit(MBayarReguler $mBayarReguler)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\MBayarReguler  $mBayarReguler
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, MBayarReguler $mBayarReguler)
    {
        $request->validate(['id' => 'required']);
        $validasi = $request->validate([
            'tgl_bayar' => 'required|date',
            // 'no_kwitansi' => 'required|unique:tb_bayar_reguler,no_kwitansi,' . $request->id . ',id_bayar_reguler',
            'periode_awal' => 'required|date',
            'id_pelajar' => 'required|numeric',
            'id_bimbel_reguler' => 'required|numeric',
        ]);
        $validasi['id_pengguna'] = auth()->user()->id_user;
        MBayarReguler::where('id_bayar_reguler', $request->id)->update($validasi);

        return redirect('/pembayaran-reguler')->with('pesan', 'Data pembayaran reguler berhasil di update');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\MBayarReguler  $mBayarReguler
     * @return \Illuminate\Http\Response
     */
    public function destroy(MBayarReguler $pembayaran_reguler)
    {
        MBayarReguler::destroy($pembayaran_reguler->id_bayar_reguler);
        return redirect('/pembayaran-reguler')->with('pesan', 'Data pembayaran reguler berhasil di hapus');
    }

    public function print(Request $request)
    {
        // dd($request->all());
        $print = MBayarReguler::query();
        if ($request->awal)
            $print->whereDate('tgl_bayar', '>=', $request->awal);

        if ($request->akhir)
            $print->whereDate('tgl_bayar', '<=', $request->akhir);
        $print = $print->with('pelajar', 'reguler')->orderBy('tgl_bayar', 'DESC')->get();
        // dd($print);
        $data = [
            'title' => 'Print Pembayaran Bimbel Reguler',
            'data' => $print,
        ];
        return view('home.bayarReguler.bayarRegulerPrint', $data);
    }

    public function kwitansi(MBayarReguler $id)
    {
        // dd($id);
        $data = [
            'title' => "Bimbel Reguler No. Kwitansi $id->no_kwitansi",
            'data' => MBayarReguler::with('pelajar', 'reguler', 'pengguna')->find($id->id_bayar_reguler),
            'jenis' => 'Biaya Reguler',
        ];
        return view('home.bayarReguler.bayarRegulerKwintansi', $data);
    }
}
