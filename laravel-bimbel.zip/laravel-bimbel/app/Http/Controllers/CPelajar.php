<?php

namespace App\Http\Controllers;

use App\Models\MPelajar;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class CPelajar extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = [
            'title' => 'Pelajar',
            'pelajar' => MPelajar::all(),
        ];
        return view('home/pelajar/pelajar', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $validasi = $request->validate([
            'nama' => 'required',
            // 'nis' => 'alpha_dash:ascii|lowercase|unique:tb_pelajar,nis',
            'telp' => 'min:10|max:15',
            'jk' => 'required',
            'kelas' => 'required',
            'alamat' => 'required',
        ]);
        MPelajar::create($validasi);
        return redirect('/pelajar')->with('pesan', 'Data pelajar berhasil di tambah');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\MPelajar  $mPelajar
     * @return \Illuminate\Http\Response
     */
    public function show(MPelajar $pelajar)
    {
        dd($pelajar);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\MPelajar  $mPelajar
     * @return \Illuminate\Http\Response
     */
    public function edit(MPelajar $pelajar)
    {
        return $pelajar;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\MPelajar  $mPelajar
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, MPelajar $pelajar)
    {
        // dd($pelajar);
        $request->validate(['id' => 'required']);
        $validasi = $request->validate([
            'nama' => 'required',
            // 'nis' => 'alpha_dash:ascii|lowercase|unique:tb_pelajar,nis,' . $request->id . ',id_pelajar',
            'telp' => 'min:10|max:15',
            'jk' => 'required',
            'kelas' => 'required',
            'alamat' => 'required',
        ]);
        MPelajar::where('id_pelajar', $pelajar->id_pelajar)->update($validasi);
        return redirect('/pelajar')->with('pesan', 'Data pelajar berhasil di update');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\MPelajar  $mPelajar
     * @return \Illuminate\Http\Response
     */
    public function destroy(MPelajar $pelajar)
    {
        MPelajar::destroy($pelajar->id_pelajar);
        return redirect('/pelajar')->with('pesan', 'Data pelajar berhasil di hapus');
    }
}
