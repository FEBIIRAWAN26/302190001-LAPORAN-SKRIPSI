<?php

namespace App\Http\Controllers;

use App\Models\MBimbelPrivate;
use Illuminate\Http\Request;

class CBimbelPrivate extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = [
            'title' => 'Program Bimbel Private',
            'data' => MBimbelPrivate::all(),
        ];
        return view('home.bimbelPrivate.bimbelPrivate', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validasi = $request->validate([
            'paket_siswa' => 'required|numeric|digits:1',
            'tingkat_sekolah' => 'required',
            'biaya' => 'required|numeric',
            'jumlah_pertemuan' => 'required|numeric|digits:1',
        ]);
        MBimbelPrivate::create($validasi);
        return redirect('/bimbel-private')->with('pesan', 'Data bimbel private berhasil di tambah');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\MBimbelPrivate  $mBimbelPrivate
     * @return \Illuminate\Http\Response
     */
    public function show(MBimbelPrivate $mBimbelPrivate)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\MBimbelPrivate  $mBimbelPrivate
     * @return \Illuminate\Http\Response
     */
    public function edit(MBimbelPrivate $mBimbelPrivate)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\MBimbelPrivate  $mBimbelPrivate
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, MBimbelPrivate $bimbel_private)
    {
        $request->validate(['id' => 'required']);
        $validasi = $request->validate([
            'paket_siswa' => 'required|numeric|digits:1',
            'tingkat_sekolah' => 'required',
            'biaya' => 'required|numeric',
            'jumlah_pertemuan' => 'required|numeric|digits:1',
        ]);
        MBimbelPrivate::where('id_bimbel_private', $bimbel_private->id_bimbel_private)->update($validasi);

        return redirect('/bimbel-private')->with('pesan', 'Data bimbel private berhasil di update');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\MBimbelPrivate  $mBimbelPrivate
     * @return \Illuminate\Http\Response
     */
    public function destroy(MBimbelPrivate $bimbel_private)
    {
        // dd($bimbel_private);
        MBimbelPrivate::destroy($bimbel_private->id_bimbel_private);
        return redirect('/bimbel-private')->with('pesan', 'Data bimbel private berhasil di hapus');
    }
}
