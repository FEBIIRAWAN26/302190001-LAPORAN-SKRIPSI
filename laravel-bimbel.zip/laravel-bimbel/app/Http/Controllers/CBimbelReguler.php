<?php

namespace App\Http\Controllers;

use App\Models\MBimbelReguler;
use Illuminate\Validation\Rule;
use Illuminate\Http\Request;

class CBimbelReguler extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = [
            'title' => 'Program Bimbel Reguler',
            'data' => MBimbelReguler::all(),
        ];
        return view('home.bimbelReguler.bimbelReguler', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data = [
            'title' => 'Tambah data bimbel reguler',
        ];
        return view('home/bimbelReguler/bimbelRegulerTambah', $data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validasi = $request->validate([
            'kelas' => 'unique:tb_bimbel_reguler,kelas',
            'biaya' => 'numeric',
            'jumlah_pertemuan' => 'numeric|digits:1,2',
        ]);
        MBimbelReguler::create($validasi);
        return redirect('/bimbel-reguler')->with('pesan', 'Data bimbel reguler berhasil di tambah');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\MBimbelReguler  $mBimbelReguler
     * @return \Illuminate\Http\Response
     */
    public function show(MBimbelReguler $mBimbelReguler)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\MBimbelReguler  $mBimbelReguler
     * @return \Illuminate\Http\Response
     */
    public function edit(MBimbelReguler $bimbelReguler)
    {
        // dd($bimbelReguler);
        $data = [
            'title' => 'Edit bimbel reguler',
            'data' => $bimbelReguler,
        ];
        return view('home/bimbelReguler/bimbelRegulerEdit', $data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\MBimbelReguler  $mBimbelReguler
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, MBimbelReguler $bimbelReguler)
    {
        $validasi = $request->validate([
            'kelas' =>  "unique:tb_bimbel_reguler,kelas,$bimbelReguler->id_bimbel_reguler,id_bimbel_reguler",
            'biaya' => 'numeric',
            'jumlah_pertemuan' => 'numeric|min:2',
        ]);
        MBimbelReguler::where('id_bimbel_reguler', $bimbelReguler->id_bimbel_reguler)->update($validasi);
        return redirect('/bimbel-reguler')->with('pesan', 'Data bimbel reguler berhasil di update');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\MBimbelReguler  $mBimbelReguler
     * @return \Illuminate\Http\Response
     */
    public function destroy(MBimbelReguler $bimbelReguler)
    {
        // dd($bimbelReguler);
        MBimbelReguler::destroy($bimbelReguler->id_bimbel_reguler);
        return redirect('/bimbel-reguler')->with('pesan', 'Data bimbel reguler berhasil di hapus');
    }
}
