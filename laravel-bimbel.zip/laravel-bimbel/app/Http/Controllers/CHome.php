<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Models\MBayarPrivate;
use App\Models\MBayarReguler;
use App\Models\MPengguna;
use Illuminate\Support\Facades\DB;

class CHome extends Controller
{
    //
    public function index()
    {
        $bulanTerakhir = Carbon::now()->subMonths(5);

        $bayarReguler = MBayarReguler::with('reguler')
            ->where('tgl_bayar', '>=', $bulanTerakhir)
            ->get()
            ->groupBy(function ($item) {
                return date('M Y', strtotime($item->tgl_bayar));
            })
            ->map(function ($grouped) {
                $totalPembayaran = $grouped->sum('reguler.biaya');
                return [
                    'bulan' => date('M Y', strtotime($grouped->first()->tgl_bayar)),
                    'totalPembayaran' => $totalPembayaran,
                ];
            })
            ->sortBy(function ($item) {
                return Carbon::parse($item['bulan']);
            })->values()->all();

        $bayarPrivate = MBayarPrivate::with('private')
            ->where('tgl_bayar', '>=', $bulanTerakhir)->get()
            ->groupBy(function ($i) {
                return date('M Y', strtotime($i->tgl_bayar));
            })->map(function ($grouped) {
                $totalPembayaran = $grouped->sum(function ($item) {
                    return $item->private->biaya / $item->private->jumlah_pertemuan * $item->jumlah_pertemuan;
                });
                return [
                    'totalPembayaran' => $totalPembayaran,
                    'bulan' => date('M Y', strtotime($grouped->first()->tgl_bayar)),
                ];
            })->sortBy(function ($item) {
                return Carbon::parse($item['bulan']);
            })->values()->all();
        // dd($bayarPrivate);



        $data = [
            'title' => 'Dashboard',
            'reguler' => MBayarReguler::with('pelajar', 'reguler')->orderBy('tgl_bayar', 'desc')->latest()->take(5)->get(),
            'private' => MBayarPrivate::with('pelajar', 'private')->orderBy('tgl_bayar', 'desc')->latest()->take(5)->get(),
            'bayarReguler' => $bayarReguler,
            'bayarPrivate' => $bayarPrivate,
        ];
        return view('home/dashboard', $data);
    }
}
