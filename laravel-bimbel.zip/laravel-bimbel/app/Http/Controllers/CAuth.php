<?php

namespace App\Http\Controllers;

use App\Models\MPengguna;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CAuth extends Controller
{
    public function index()
    {

        $data = [
            'title' => 'Login',
            'desc' => 'Silahkan login',
        ];
        return view('login', $data);
    }

    public function authenticate(Request $req)
    {
        $credentials = $req->validate([
            // 'email' => 'email:dns',
            'username' => 'required',
            'password' => 'required'
        ]);
        // dd($req);
        $pengguna = MPengguna::where('username', $req->username)->first();
        // dd($pengguna);
        if ($pengguna && $pengguna->is_active == 0) {
            return back()->with('gagal', 'Akun belum diaktifkan');
        } else {

            if (Auth::attempt($credentials)) {
                $req->session()->regenerate();
                // return  auth()->user()->nama;
                if (auth()->user()->status == 'owner') {
                    $pengguna = MPengguna::where('is_active', 0)->get();
                    if ($pengguna) {
                        $nonActive = [];
                        foreach ($pengguna as $i) {
                            $nonActive[] = $i->nama;
                        }
                        session()->flash('non_active', $nonActive);
                    }
                }
                return redirect()->intended('/dashboard');
            }
            return back()->with('gagal', 'Username atau Password anda salah');
        }
    }

    public function logout(Request $req)
    {
        Auth::logout();
        $req->session()->invalidate();
        $req->session()->regenerateToken();
        return redirect('/');
    }
}
