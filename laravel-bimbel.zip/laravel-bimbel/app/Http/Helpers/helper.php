<?php

// use NumberFormatter;

function uangText($uang)
{
    $format = new NumberFormatter('id_ID', NumberFormatter::SPELLOUT);
    return $format->format($uang) . ' rupiah';
}

function FHelper()
{
    return 'ini Helper';
}

function rupiah($uang)
{
    $rp = number_format($uang, 0, ',', '.');
    return "Rp. " . $rp;
}

// rupiah(12000)//Rp. 12.000

function tanggal($date)
{
    return date('d M Y', strtotime($date));
}

function bulanDepan($tgl)
{
    return tanggal(date('Y-m-d', strtotime('+30 day', strtotime($tgl))));
}

//procedure
function notifFailed($all)
{
?>
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        <ul>
            <?php
            foreach ($all as $error) {
                echo "<li>$error</li>";
            }
            ?>
        </ul>
    </div>
<?php
}

function inputText($name, $label, $valid, $type = 'text', $req = 'required', $min = 1, $max = 100)
{
?>
    <div class="form-floating mb-3">
        <input type="<?= $type ?>" name="<?= $name ?>" placeholder="<?= $label ?>" minlength="<?= $min ?>" maxlength="<?= $max ?>" autofocus <?= $req ?> class="form-control" id="<?= $name ?>" value="<?= $valid ?>">
        <label for="<?= $name ?>"><?= $label ?></label>
    </div>
<?php
}

function inputRadio($name, $label, $value, $old = '', $required = 'required')
{
?>
    <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="<?= $name ?>" id="<?= $value ?>" value="<?= $value ?>" <?= $required ?> <?= $old == $value ? 'checked' : '' ?>>
        <label class="form-check-label" for="<?= $value ?>"><?= $label ?></label>
    </div>
<?php
}
function inputRadioNoWajib($name, $label, $value, $old = '')
{
?>
    <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="<?= $name ?>" id="<?= $value ?>" value="<?= $value ?>" <?= $old == $value ? 'checked' : '' ?>>
        <label class="form-check-label" for="<?= $value ?>"><?= $label ?></label>
    </div>
<?php
}
function selectRelasi($name, $label, $relasi, $old = '', $id = '', $val = '')
{
    // dd($id, $val);
?>
    <div class="input-group mb-3">
        <label class="input-group-text" for="<?= $name ?>"><?= $label ?></label>
        <select class="form-select" name="<?= $name ?>" id="<?= $name ?>" required="required">
            <?php
            foreach ($relasi as $item) {
            ?>
                <option <?= $old == $item->$id ? 'selected' : '' ?> value="<?= $item->$id ?>">
                    <?= $item->$val; ?>
                </option>
            <?php } ?>
        </select>
    </div>
<?php
}
