<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SBimbelReguler extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('tb_bimbel_reguler')->truncate();
        //bimbel reguler
        DB::table('tb_bimbel_reguler')->insert([
            'kelas' => '1',
            'biaya' => 200000,
            'jumlah_pertemuan' => '3'
        ]);
        DB::table('tb_bimbel_reguler')->insert([
            'kelas' => '2',
            'biaya' => 200000,
            'jumlah_pertemuan' => '3'
        ]);
        DB::table('tb_bimbel_reguler')->insert([
            'kelas' => '3',
            'biaya' => 200000,
            'jumlah_pertemuan' => '3'
        ]);

        DB::table('tb_bimbel_reguler')->insert([
            'kelas' => '4',
            'biaya' => 250000,
            'jumlah_pertemuan' => '4'
        ]);
        DB::table('tb_bimbel_reguler')->insert([
            'kelas' => '5',
            'biaya' => 250000,
            'jumlah_pertemuan' => '4'
        ]);
        DB::table('tb_bimbel_reguler')->insert([
            'kelas' => '6',
            'biaya' => 250000,
            'jumlah_pertemuan' => '4'
        ]);

        DB::table('tb_bimbel_reguler')->insert([
            'kelas' => '7',
            'biaya' => 250000,
            'jumlah_pertemuan' => '3'
        ]);
        DB::table('tb_bimbel_reguler')->insert([
            'kelas' => '8',
            'biaya' => 250000,
            'jumlah_pertemuan' => '3'
        ]);

        DB::table('tb_bimbel_reguler')->insert([
            'kelas' => '9',
            'biaya' => 325000,
            'jumlah_pertemuan' => '4'
        ]);

        DB::table('tb_bimbel_reguler')->insert([
            'kelas' => '10',
            'biaya' => 300000,
            'jumlah_pertemuan' => '3'
        ]);
        DB::table('tb_bimbel_reguler')->insert([
            'kelas' => '11',
            'biaya' => 300000,
            'jumlah_pertemuan' => '3'
        ]);

        DB::table('tb_bimbel_reguler')->insert([
            'kelas' => '12',
            'biaya' => 400000,
            'jumlah_pertemuan' => '4'
        ]);

        DB::table('tb_bimbel_reguler')->insert([
            'kelas' => 'umum',
            'biaya' => 450000,
            'jumlah_pertemuan' => '4'
        ]);
    }
}
