<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call([
            SBimbelReguler::class,
            SBimbelPrivate::class,
        ]);
        // \App\Models\User::factory(10)->create();
        //pengguna
        DB::table('users')->insert([
            'username' => 'admin',
            'password' => bcrypt('admin'),
            'password2' => 'admin',
            'nama' => 'Febi Irawan',
            'telp' => '085333334444',
            'status' => 'admin',
            'is_active' => 1,
        ]);

        DB::table('users')->insert([
            'username' => 'owner',
            'password' => bcrypt('owner'),
            'password2' => 'owner',
            'nama' => 'Junaedi Pamungkas',
            'telp' => '085722227777',
            'status' => 'owner',
            'is_active' => 1,
        ]);
        DB::table('users')->insert([
            'username' => 'manajer',
            'password' => bcrypt('manajer'),
            'password2' => 'manajer',
            'nama' => 'Sumbul Alnabawi',
            'telp' => '085722227777',
            'status' => 'manajer',
            'is_active' => 1,
        ]);

        //pelajar
        DB::table('tb_pelajar')->insert([
            // 'nis' => '801237263',
            'nama' => 'Juned',
            'kelas' => '8',
            'jk' => 'L',
            'alamat' => 'Jl. Adipati kertamanah Baleendah',
            'telp' => '085722227777',
        ]);
        DB::table('tb_pelajar')->insert([
            // 'nis' => '80156263',
            'nama' => 'Ucup',
            'kelas' => '5',
            'jk' => 'L',
            'alamat' => 'Jl. Adipati kertamanah Baleendah',
            'telp' => '08572666888',
        ]);

        //bayar reguler
        DB::table('tb_bayar_reguler')->insert([
            'tgl_bayar' => date('Y-m-d'),
            'no_kwitansi' => 'R0001',
            'id_pelajar' => 1,
            'periode_awal' => date('Y-m-d'),
            'id_bimbel_reguler' => 1,
            'id_pengguna' => 1
        ]);

        //pertemuan
        DB::table('tb_pertemuan')->insert([
            'tgl' => date('Y-m-d'),
            'id_bayar' => 1,
            'ket' => 'P',
        ]);

        //bayar private
        DB::table('tb_bayar_private')->insert([
            'tgl_bayar' => date('Y-m-d'),
            'no_kwitansi' => 'P0001',
            'jumlah_pertemuan' => 2,
            'id_pelajar' => 1,
            'id_bimbel_private' => 1,
            'id_pengguna' => 1
        ]);
        DB::table('tb_bayar_private')->insert([
            'tgl_bayar' => date('Y-m-d'),
            'no_kwitansi' => 'P0002',
            'jumlah_pertemuan' => 5,
            'id_pelajar' => 2,
            'id_bimbel_private' => 5,
            'id_pengguna' => 1
        ]);
    }
}
