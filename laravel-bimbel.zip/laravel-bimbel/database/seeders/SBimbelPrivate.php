<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\MBimbelPrivate;

class SBimbelPrivate extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // MBimbelPrivate::truncate();
        //1
        MBimbelPrivate::create(
            [
                'paket_siswa' => 1,
                'tingkat_sekolah' => 'SD',
                'biaya' => 480000,
                'jumlah_pertemuan' => '8'
            ]
        );
        MBimbelPrivate::create(
            [
                'paket_siswa' => 1,
                'tingkat_sekolah' => 'SMP',
                'biaya' => 640000,
                'jumlah_pertemuan' => '8'
            ]
        );
        MBimbelPrivate::create(
            [
                'paket_siswa' => 1,
                'tingkat_sekolah' => 'SMA',
                'biaya' => 960000,
                'jumlah_pertemuan' => '8'
            ]
        );
        //2
        MBimbelPrivate::create(
            [
                'paket_siswa' => 2,
                'tingkat_sekolah' => 'SD',
                'biaya' => 430000,
                'jumlah_pertemuan' => '8'
            ]
        );
        MBimbelPrivate::create(
            [
                'paket_siswa' => 2,
                'tingkat_sekolah' => 'SMP',
                'biaya' => 480000,
                'jumlah_pertemuan' => '8'
            ]
        );
        MBimbelPrivate::create(
            [
                'paket_siswa' => 2,
                'tingkat_sekolah' => 'SMA',
                'biaya' => 900000,
                'jumlah_pertemuan' => '8'
            ]
        );

        //3
        MBimbelPrivate::create(
            [
                'paket_siswa' => 3,
                'tingkat_sekolah' => 'SD',
                'biaya' => 380000,
                'jumlah_pertemuan' => '8'
            ]
        );
        MBimbelPrivate::create(
            [
                'paket_siswa' => 3,
                'tingkat_sekolah' => 'SMP',
                'biaya' => 400000,
                'jumlah_pertemuan' => '8'
            ]
        );
        MBimbelPrivate::create(
            [
                'paket_siswa' => 3,
                'tingkat_sekolah' => 'SMA',
                'biaya' => 840000,
                'jumlah_pertemuan' => '8'
            ]
        );

        //4
        MBimbelPrivate::create(
            [
                'paket_siswa' => 4,
                'tingkat_sekolah' => 'SD',
                'biaya' => 330000,
                'jumlah_pertemuan' => '8'
            ]
        );
        MBimbelPrivate::create(
            [
                'paket_siswa' => 4,
                'tingkat_sekolah' => 'SMP',
                'biaya' => 320000,
                'jumlah_pertemuan' => '8'
            ]
        );
        MBimbelPrivate::create(
            [
                'paket_siswa' => 4,
                'tingkat_sekolah' => 'SMA',
                'biaya' => 780000,
                'jumlah_pertemuan' => '8'
            ]
        );

        //5
        MBimbelPrivate::create(
            [
                'paket_siswa' => 5,
                'tingkat_sekolah' => 'SD',
                'biaya' => 280000,
                'jumlah_pertemuan' => '8'
            ]
        );
        MBimbelPrivate::create(
            [
                'paket_siswa' => 5,
                'tingkat_sekolah' => 'SMP',
                'biaya' => 300000,
                'jumlah_pertemuan' => '8'
            ]
        );
        MBimbelPrivate::create(
            [
                'paket_siswa' => 5,
                'tingkat_sekolah' => 'SMA',
                'biaya' => 720000,
                'jumlah_pertemuan' => '8'
            ]
        );
    }
}
