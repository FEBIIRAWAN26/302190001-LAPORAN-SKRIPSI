<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class BimbelPrivate extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tb_bimbel_private', function (Blueprint $table) {
            $table->increments('id_bimbel_private');
            $table->integer('paket_siswa');
            $table->text('tingkat_sekolah');
            $table->bigInteger('biaya');
            $table->integer('jumlah_pertemuan');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
