<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class PembayaranReguler extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tb_bayar_reguler', function (Blueprint $table) {
            $table->increments('id_bayar_reguler');
            $table->date('tgl_bayar');
            $table->text('no_kwitansi');
            $table->foreignId('id_pelajar');
            $table->date('periode_awal');
            $table->foreignId('id_bimbel_reguler');
            $table->foreignId('id_pengguna');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
