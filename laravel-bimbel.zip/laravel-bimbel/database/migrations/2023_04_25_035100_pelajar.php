<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class Pelajar extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tb_pelajar', function (Blueprint $table) {
            $table->increments('id_pelajar');
            // $table->text('nis');
            $table->text('nama');
            $table->text('kelas');
            $table->enum('jk', ['L', 'P']);
            $table->text('alamat');
            $table->text('telp');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tb_pelajar');
    }
}
