<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- <link type="text/css" href="assets/css/sweetalert2.min.css" rel="stylesheet">
    <link type="text/css" href="assets/css/notyf.min.css" rel="stylesheet"> -->
    <title>Bimbingan Belajar</title>

    <link type="text/css" href="/css/volt.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link type="text/css" href="/css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.4/font/bootstrap-icons.css">
    
    <style>
        table#cekTabel tr th {
            text-align: center;
        }
    </style>
</head>

<body>
    <?php
        if (auth()->user()->status == 'admin') {
            $bg = 'bg-primary';
        } elseif (Auth::user()->status == 'owner') {
            $bg = 'bg-success';
        } else {
            $bg = 'bg-danger';
        }
        
        if ($title !== 'Dashboard') {
            $judul = $title;
        } else {
            $judul = $title . ' ' . ucwords(auth()->user()->status);
        }
    ?>

    <header>
        <nav class="navbar navbar-expand-lg <?php echo e($bg); ?> position-fixed w-100 text-white z-2 top-0">
            <div class="container-fluid">
                <a class="navbar-brand ms-5" href="/dashboard">Bimbel </a>
                <a href="" class="ms-7" id="tomTogle">
                    <h3><i class="bi bi-list"></i></h3>
                </a>
                <div class="collapse navbar-collapse d-flex justify-content-end me-5" id="navbarNavDropdown">
                    <ul class="navbar-nav">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                                aria-expanded="false">
                                <img class="avatar rounded-circle me-1" alt="Image placeholder"
                                    src="https://w7.pngwing.com/pngs/81/570/png-transparent-profile-logo-computer-icons-user-user-blue-heroes-logo-thumbnail.png">
                                <?php echo e(auth()->user()->nama); ?>

                            </a>
                            <ul class="dropdown-menu">
                                <form action="/logout" method="post">
                                    <?php echo csrf_field(); ?>
                                    <button class="dropdown-item"><i class="bi bi-box-arrow-right me-1 ms-1"></i>
                                        logout
                                    </button>
                                </form>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <nav id="sidebarMenu" style="top: 60px;" class=" pt-2 sidebar d-lg-block bg-gray-800 text-white collapse z-1"
            data-simplebar>
            
            <?php echo $__env->make('home/layout/nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </nav>
    </header>
    <main class="content mt-5" id="main">
        <nav class="navbar navbar-top navbar-expand navbar-dashboard navbar-dark mx-0">
            <div class="container-fluid px-0">
                <div class="d-flex justify-content-between w-100" id="navbarSupportedContent">
                    <h2 class="py-4"><?php echo e($judul); ?> </h2>
                </div>
            </div>
        </nav>
        <div style="min-height: 440px">
            <?php echo $__env->yieldContent('main'); ?>
        </div>
        <footer>
            <h6 class="text-center mt-4">&copy; Pembayaran Bimbel <?php echo e(date('Y')); ?></h6>
        </footer>
    </main>

    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>


    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#cekTabel').DataTable({
                "lengthMenu": [
                    [5, 10, 25, -1],
                    [5, 10, 25, "All"]
                ],
                "pageLength": 5
            });
        });
    </script>

    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script type="text/javascript">
        $('.show_confirm').click(function(event) {
            let form = $(this).closest("form");
            let name = $(this).data("name");
            event.preventDefault();
            Swal.fire({
                title: 'Yakin hapus data ?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    form.submit();
                }
            });
        });
    </script>

    
    <script>
        // $(document).ready(function() {
        const t = $('#tomTogle')
        t.removeAttr('href')
        t.click(function() {
            // alert('ada'
            $('#sidebarMenu').toggleClass('sidebarMenu');
            $('#main').toggleClass('main');
        });
        // });
    </script>
    <?php if($errors->any()): ?>
        <?php if(old('id')): ?>
            <script>
                $(document).ready(function() {
                    $('#edit<?php echo e(old('id')); ?>').modal('show');
                })
            </script>
        <?php else: ?>
            <script>
                $(document).ready(function() {
                    $('#new').modal('show');
                })
            </script>
        <?php endif; ?>
    <?php endif; ?>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <?php echo $__env->yieldContent('js-custom'); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\Temen\laravel-bimbel\resources\views/home/layout/layout.blade.php ENDPATH**/ ?>