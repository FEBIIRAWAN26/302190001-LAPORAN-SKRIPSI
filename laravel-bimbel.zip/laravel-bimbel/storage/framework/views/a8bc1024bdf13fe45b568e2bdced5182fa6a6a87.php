

<?php $__env->startSection('main'); ?>
    <!-- Modal Body -->
    <!-- if you want to close by clicking outside the modal, delete the last endpoint:data-bs-backdrop and data-bs-keyboard -->
    <div class="modal fade" id="print" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false" role="dialog"
        aria-labelledby="modalTitleId" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable modal-lg my-3" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitleId">Laporan</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="/pembayaran-private/print" method="post" target="_blank">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <?php
                            inputText('awal', 'Tanggal awal', '', 'date', '');
                            inputText('akhir', 'Tanggal akhir', '', 'date', '');
                        ?>
                    </div>
                    <div class="modal-footer">
                        <button type="reset" class="btn btn-secondary">Reset</button>
                        <button type="submit" class="btn btn-primary">Print</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="row pasLayar">
        <div class="col-12">
            <div class="card shadow-sm">
                
                <div class="card-body table-responsive">
                    <?php if(session()->has('pesan')): ?>
                        <?php if (isset($component)) { $__componentOriginal338dcaad0951360b957e1d8e2e64f8056fbe8697 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Notif::class, ['pesan' => session('pesan')]); ?>
<?php $component->withName('notif'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal338dcaad0951360b957e1d8e2e64f8056fbe8697)): ?>
<?php $component = $__componentOriginal338dcaad0951360b957e1d8e2e64f8056fbe8697; ?>
<?php unset($__componentOriginal338dcaad0951360b957e1d8e2e64f8056fbe8697); ?>
<?php endif; ?>
                    <?php endif; ?>
                    
                    <!-- Modal trigger button -->
                    <div class="mb-3">
                        
                        <button type="button" class="btn btn-primary me-2" title="Tambah data" data-bs-toggle="modal"
                            data-bs-target="#new">
                            <i class="bi bi-bookmark-plus"></i> Tambah
                        </button>
                        <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#print"
                            title="Cetak laporan">
                            <i class="bi bi-printer-fill"></i> Print
                        </button>
                        
                    </div>

                    
                    <div class="modal fade" id="new" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false"
                        role="dialog" aria-labelledby="modalTitleId" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-scrollable modal-lg my-3" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="modalTitleId">Tambah data</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <form action="/pembayaran-private" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="modal-body modalCustom">
                                        <?php if($errors->any() && !old('id')): ?>
                                            <?php
                                                notifFailed($errors->all());
                                                $tgl_bayar = old('tgl_bayar');
                                                // $no_kwitansi = old('no_kwitansi');
                                                $jumlah_pertemuan = old('jumlah_pertemuan');
                                                $id_bimbel_private = old('id_bimbel_private');
                                                $id_pelajar = old('id_pelajar');
                                            ?>
                                        <?php else: ?>
                                            <?php
                                                $tgl_bayar = '';
                                                // $no_kwitansi = '';
                                                $jumlah_pertemuan = '';
                                                $id_bimbel_private = '';
                                                $id_pelajar = '';
                                            ?>
                                        <?php endif; ?>

                                        <?php
                                            inputText('tgl_bayar', 'Tanggal pembayaran', $tgl_bayar, 'date');
                                            // inputText('no_kwitansi', 'No. kwitansi', $no_kwitansi);
                                        ?>
                                        <div class="form-floating mb-3">
                                            <select class="form-select" name="id_pelajar" id="id_pelajar"
                                                aria-label="Floating label select example">
                                                <?php $__currentLoopData = $pelajar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php echo e($id_pelajar == $item->id_pelajar ? 'selected' : ''); ?>

                                                        value="<?php echo e($item->id_pelajar); ?>">
                                                        <?php echo e('Nama : ' . $item->nama . ' | Kelas : ' . $item->kelas); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <label for="id_bimbel_private">Paket bimbel</label>
                                        </div>
                                        <?php
                                            inputText('jumlah_pertemuan', 'Jumlah pertemuan', $jumlah_pertemuan, 'number');
                                        ?>
                                        <div class="form-floating mb-3">
                                            <select class="form-select" name="id_bimbel_private" id="id_bimbel_private"
                                                aria-label="Floating label select example">
                                                <?php $__currentLoopData = $private; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option
                                                        <?php echo e($id_bimbel_private == $item->id_bimbel_private ? 'selected' : ''); ?>

                                                        value="<?php echo e($item->id_bimbel_private); ?>">
                                                        <?php echo e($item->paket_siswa . ' pelajar | sekolah ' . $item->tingkat_sekolah); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <label for="id_bimbel_private">Paket bimbel</label>
                                        </div>

                                    </div>
                                    <div class="modal-footer">
                                        <button type="reset" class="btn btn-secondary">Reset</button>
                                        <button type="Submit" class="btn btn-primary">Simpan</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <table id="cekTabel" class="table table-nowrap table-centered rounded table-bordered border-dark">
                        <thead class="bg-primary text-center">
                            <tr>
                                <th class="text-white ">No</th>
                                <th class="text-white">Tanggal</th>
                                <th class="text-white">Kwitansi</th>
                                <th class="text-white">Pelajar</th>
                                <th class="text-white">Biaya</th>
                                <th class="text-white">Pertemuan</th>
                                <th class="text-white">Pilihan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                    <td class="text-center"><?php echo e(tanggal($p->tgl_bayar)); ?></td>
                                    <td><?php echo e($p->no_kwitansi); ?></td>
                                    <td><?php echo e($p->pelajar->nama); ?> </td>
                                    <td class="text-end">
                                        <?php echo e(rupiah(($p->private->biaya / $p->private->jumlah_pertemuan) * $p->jumlah_pertemuan)); ?>

                                    </td>
                                    <td class="text-center"><?php echo e($p->jumlah_pertemuan); ?> x</td>
                                    <td>
                                        
                                        
                                        <button type="button" class="btn btn-warning" title="Edit data"
                                            data-bs-toggle="modal" data-bs-target="#edit<?php echo e($p->id_bayar_private); ?>">
                                            <i class="bi bi-pencil-square"></i>
                                        </button>
                                        
                                        <div class="modal fade" id="edit<?php echo e($p->id_bayar_private); ?>" tabindex="-1"
                                            data-bs-backdrop="static" data-bs-keyboard="false" role="dialog"
                                            aria-labelledby="modalTitleId" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-scrollable modal-lg my-3"
                                                role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="modalTitleId">Edit data</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <form action="/pembayaran-private/<?php echo e($p->id_bayar_private); ?>"
                                                        method="post">
                                                        <?php echo method_field('put'); ?>
                                                        <?php echo csrf_field(); ?>
                                                        <div class="modal-body modalCustom">
                                                            <input type="hidden" name="id"
                                                                value="<?php echo e($p->id_bayar_private); ?>">
                                                            <?php if($errors->any() && old('id') == $p->id_bayar_private): ?>
                                                                <?php
                                                                    notifFailed($errors->all());
                                                                    $tgl_bayar = old('tgl_bayar');
                                                                    // $no_kwitansi = old('no_kwitansi');
                                                                    $jumlah_pertemuan = old('jumlah_pertemuan');
                                                                    $id_bimbel_private = old('id_bimbel_private');
                                                                    $id_pelajar = old('id_pelajar');
                                                                ?>
                                                            <?php else: ?>
                                                                <?php
                                                                    $tgl_bayar = $p->tgl_bayar;
                                                                    // $no_kwitansi = $p->no_kwitansi;
                                                                    $jumlah_pertemuan = $p->jumlah_pertemuan;
                                                                    $id_bimbel_private = $p->id_bimbel_private;
                                                                    $id_pelajar = $p->id_pelajar;
                                                                ?>
                                                            <?php endif; ?>

                                                            <?php
                                                                inputText('tgl_bayar', 'Tanggal pembayaran', $tgl_bayar, 'date');
                                                                // inputText('no_kwitansi', 'No. kwitansi', $no_kwitansi);
                                                            ?>
                                                            <div class="form-floating mb-3">
                                                                <select class="form-select" name="id_pelajar"
                                                                    id="id_pelajar"
                                                                    aria-label="Floating label select example">
                                                                    <?php $__currentLoopData = $pelajar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option
                                                                            <?php echo e($id_pelajar == $item->id_pelajar ? 'selected' : ''); ?>

                                                                            value="<?php echo e($item->id_pelajar); ?>">
                                                                            <?php echo e('Nama : ' . $item->nama . ' | Kelas : ' . $item->kelas); ?>

                                                                        </option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                                <label for="id_bimbel_private">Paket bimbel</label>
                                                            </div>
                                                            <?php
                                                                inputText('jumlah_pertemuan', 'Jumlah pertemuan', $jumlah_pertemuan, 'number');
                                                            ?>
                                                            <div class="form-floating mb-3">
                                                                <select class="form-select" name="id_bimbel_private"
                                                                    id="id_bimbel_private"
                                                                    aria-label="Floating label select example">
                                                                    <?php $__currentLoopData = $private; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option
                                                                            <?php echo e($id_bimbel_private == $item->id_bimbel_private ? 'selected' : ''); ?>

                                                                            value="<?php echo e($item->id_bimbel_private); ?>">
                                                                            <?php echo e($item->paket_siswa . ' pelajar | sekolah ' . $item->tingkat_sekolah); ?>

                                                                        </option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                                <label for="id_bimbel_private">Paket bimbel</label>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="reset"
                                                                class="btn btn-secondary">Reset</button>
                                                            <button type="Submit" class="btn btn-primary">Update</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <form action="/pembayaran-private/<?php echo e($p->id_bayar_private); ?>" method="post"
                                            class="d-inline">
                                            <?php echo method_field('delete'); ?>
                                            <?php echo csrf_field(); ?>
                                            <button title="Hapus data" class="btn btn-danger show_confirm"><i
                                                    class="bi bi-trash-fill"></i></button>
                                        </form>
                                        <a href="/pembayaran-private/kwitansi/<?php echo e($p->id_bayar_private); ?>" target="_blank"
                                            class="btn btn-success" title="Cetak kwitansi"><i
                                                class="bi bi-file-earmark-text-fill"></i></a>
                                        
                                        <a href="/pembayaran-private/pertemuan/<?php echo e($p->id_bayar_private); ?>"
                                            title="Pertemuan bimbel" class="btn btn-info "><i
                                                class="bi bi-card-checklist"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home/layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Temen\laravel-bimbel\resources\views/home/bayarPrivate/bayarPrivate.blade.php ENDPATH**/ ?>