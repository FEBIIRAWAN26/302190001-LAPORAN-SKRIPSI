
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    <b><i class="bi bi-check-lg"></i></b> <?php echo e(isset($pesan) ? $pesan : ''); ?>

</div>
<?php /**PATH C:\xampp\htdocs\Temen\laravel-bimbel\resources\views/components/notif.blade.php ENDPATH**/ ?>