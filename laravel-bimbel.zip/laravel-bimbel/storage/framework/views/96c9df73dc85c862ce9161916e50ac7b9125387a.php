

<?php $__env->startSection('main'); ?>
    <div class="row ">
        <div class="col-12">
            <div class="card shadow-sm">
                
                <div class="card-body table-responsive">
                    <?php if(session()->has('pesan')): ?>
                        <?php if (isset($component)) { $__componentOriginal338dcaad0951360b957e1d8e2e64f8056fbe8697 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Notif::class, ['pesan' => session('pesan')]); ?>
<?php $component->withName('notif'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal338dcaad0951360b957e1d8e2e64f8056fbe8697)): ?>
<?php $component = $__componentOriginal338dcaad0951360b957e1d8e2e64f8056fbe8697; ?>
<?php unset($__componentOriginal338dcaad0951360b957e1d8e2e64f8056fbe8697); ?>
<?php endif; ?>
                    <?php endif; ?>
                    
                    <button type="button" class="btn btn-primary mb-3" title="Tambah data" data-bs-toggle="modal"
                        data-bs-target="#new">
                        <i class="bi bi-bookmark-plus"></i> Tambah
                    </button>
                    

                    
                    <div class="modal fade" id="new" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false"
                        role="dialog" aria-labelledby="modalTitleId" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-scrollable modal-lg my-3" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="modalTitleId">Tambah data</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <form action="/pelajar" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="modal-body modalCustom">
                                        <?php if($errors->any() && !old('id')): ?>
                                            <?php
                                                notifFailed($errors->all());
                                                $nama = old('nama');
                                                // $nis = old('nis');
                                                $kelas = old('kelas');
                                                $alamat = old('alamat');
                                                $telp = old('telp');
                                                $jk = old('jk');
                                            ?>
                                        <?php else: ?>
                                            <?php
                                                $nama = '';
                                                // $nis = '';
                                                $kelas = '';
                                                $alamat = '';
                                                $telp = '';
                                                $jk = '';
                                            ?>
                                        <?php endif; ?>

                                        <?php
                                            // inputText('nis', 'NIS', $nis);
                                        ?>
                                        
                                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input','data' => ['name' => 'nama','label' => 'Nama lengkap','req' => 'required','val' => $nama]]); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('nama'),'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Nama lengkap'),'req' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('required'),'val' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($nama)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                        <?php
                                            // inputText('nama', 'Nama lengkap', $nama);
                                            inputText('kelas', 'Kelas ', $kelas);
                                            inputText('telp', 'Nomor telepon', $telp, 'number', 10, 15);
                                            inputText('alamat', 'Alamat', $alamat);
                                        ?>
                                        <h6>Jenis kelamin</h6>
                                        <?php
                                            inputRadio('jk', 'Laki-laki', 'L', $jk);
                                            inputRadio('jk', 'Perempuan', 'P', $jk);
                                        ?>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="reset" class="btn btn-secondary">Reset</button>
                                        <button type="Submit" class="btn btn-primary">Simpan</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <table id="cekTabel" class="table table-nowrap table-centered rounded table-bordered border-dark">
                        <thead class="bg-primary">
                            <tr>
                                <th class="text-white">No</th>
                                
                                <th class="text-white">Nama</th>
                                <th class="text-white">Gender</th>
                                <th class="text-white">Kelas</th>
                                <th class="text-white">Alamat</th>
                                <th class="text-white">Telepon</th>
                                
                                <th class="text-white">Pilihan</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $pelajar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                    
                                    <td><?php echo e($p->nama); ?></td>
                                    <td><?php echo e($p->jk); ?></td>
                                    <td class="text-center"><?php echo e($p->kelas); ?></td>
                                    <td><?php echo e($p->alamat); ?></td>
                                    <td><?php echo e($p->telp); ?></td>
                                    
                                    <td>
                                        
                                        <button type="button" class="btn btn-warning me-2" data-bs-toggle="modal"
                                            data-bs-target="#edit<?php echo e($p->id_pelajar); ?>">
                                            <i class="bi bi-pencil-square"></i>
                                        </button>
                                        
                                        <div class="modal fade" id="edit<?php echo e($p->id_pelajar); ?>" tabindex="-1"
                                            data-bs-backdrop="static" data-bs-keyboard="false" role="dialog"
                                            aria-labelledby="modalTitleId" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-scrollable modal-lg my-3" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="modalTitleId">Edit data</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <form action="/pelajar/<?php echo e($p->id_pelajar); ?>" method="post">
                                                        <?php echo method_field('put'); ?>
                                                        <?php echo csrf_field(); ?>
                                                        <div class="modal-body modalCustom">
                                                            <?php if($errors->any() && old('id') == $p->id_pelajar): ?>
                                                                <?php
                                                                    notifFailed($errors->all());
                                                                    $nama = old('nama');
                                                                    // $nis = old('nis');
                                                                    $kelas = old('kelas');
                                                                    $alamat = old('alamat');
                                                                    $telp = old('telp');
                                                                    $jk = old('jk');
                                                                ?>
                                                            <?php else: ?>
                                                                <?php
                                                                    $nama = $p->nama;
                                                                    // $nis = $p->nis;
                                                                    $kelas = $p->kelas;
                                                                    $alamat = $p->alamat;
                                                                    $telp = $p->telp;
                                                                    $jk = $p->jk;
                                                                ?>
                                                            <?php endif; ?>
                                                            <input type="hidden" name="id"
                                                                value="<?php echo e($p->id_pelajar); ?>">
                                                            
                                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input','data' => ['name' => 'nama','label' => 'Nama lengkap','val' => $nama,'req' => 'required']]); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('nama'),'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Nama lengkap'),'val' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($nama),'req' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('required')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                                            <?php
                                                                // inputText('nis', 'NIS', $nis);
                                                                // inputText('nama', 'Nama lengkap', $nama);
                                                                inputText('kelas', 'Kelas ', $kelas);
                                                                inputText('telp', 'Nomor telepon', $telp, 'number', 10, 15);
                                                                inputText('alamat', 'Alamat', $alamat);
                                                            ?>
                                                            <h6>Jenis kelamin</h6>
                                                            <?php
                                                                inputRadio('jk', 'Laki-laki', 'L', $jk);
                                                                inputRadio('jk', 'Perempuan', 'P', $jk);
                                                            ?>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="reset" class="btn btn-secondary">Reset</button>
                                                            <button type="Submit" class="btn btn-primary">Update</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                        <form action="/pelajar/<?php echo e($p->id_pelajar); ?>" method="post" class="d-inline">
                                            <?php echo method_field('delete'); ?>
                                            <?php echo csrf_field(); ?>
                                            <button title="Hapus data" class="btn btn-danger show_confirm"><i
                                                    class="bi bi-trash-fill"></i></button>
                                        </form>
                                    </td>
                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home/layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Temen\laravel-bimbel\resources\views/home/pelajar/pelajar.blade.php ENDPATH**/ ?>