

<div class="form-floating mb-3">
    <input type="<?= isset($type) ? $type : 'text' ?>" name="<?= $name ?>" placeholder="<?= $label ?>"
        minlength="<?= isset($minL) ? $minL : '' ?>" maxlength="<?= isset($maxL) ? $maxL : '' ?>"
        min="<?php echo e(isset($min) ? $min : ''); ?>" max="<?php echo e(isset($max) ? $max : ''); ?>" autofocus <?= isset($req) ? $req : '' ?>
        class="form-control" id="<?= $name ?>" value="<?= isset($val) ? $val : '' ?>">
    <label for="<?= $name ?>"><?= $label ?></label>
</div>
<?php /**PATH C:\xampp\htdocs\Temen\laravel-bimbel\resources\views/components/input.blade.php ENDPATH**/ ?>