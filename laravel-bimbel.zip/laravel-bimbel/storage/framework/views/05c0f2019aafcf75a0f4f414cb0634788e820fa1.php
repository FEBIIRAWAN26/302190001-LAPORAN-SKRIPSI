

<?php $__env->startSection('main'); ?>
    <h1>ini di pengguna/home.blade</h1>
    <h2>
        <?php echo e(auth()->user()->nama); ?>

        <br>
        <?php echo e(auth()->user()->status); ?>

    </h2>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
        <a href="/pengguna">Pengguna</a>
    <?php endif; ?>
    <br>

    
    <p><?php echo e($desc); ?></p>
    
    

    <form action="/logout" method="post">
        <?php echo csrf_field(); ?>
        <button class="">logout</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pengguna/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Temen\laravel-bimbel\resources\views/pengguna/home.blade.php ENDPATH**/ ?>