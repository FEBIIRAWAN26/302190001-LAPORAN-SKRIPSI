<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.headerPrint','data' => ['title' => ''.e($title).'']]); ?>
<?php $component->withName('headerPrint'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => ''.e($title).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<div class="container">
    <header class="pb-3 position-relative">
        <img src="/img/blc-logo.png" width="75px" alt="Logo BLC" class="position-absolute">
        <h2 class="text-center pt-4">Data Pembayaran Bimbel Reguler</h2>
    </header>
    <div class="border-top border-2 border-dark mb-4"></div>
    <main>
        <table class="table table-bordered border-dark">
            <thead class="bg-secondary text-white">
                <tr>
                    <th>No </th>
                    <th>Tanggal</th>
                    <th>Kwitansi</th>
                    <th>Pelajar</th>
                    <th>Biaya</th>
                    <th>Pertemuan</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $jml = 0;
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center"><?php echo e($loop->iteration); ?></td>
                        <td class="text-center"><?php echo e(tanggal($item->tgl_bayar)); ?></td>
                        <td class="text-center"><?php echo e($item->no_kwitansi); ?></td>
                        <td><?php echo e($item->pelajar->nama); ?></td>
                        <td class="text-end">
                            <?php echo e(rupiah($bayar = $item->reguler->biaya)); ?>

                        </td>
                        <td class="text-end"><?php echo e($item->reguler->jumlah_pertemuan . ' x'); ?></td>
                    </tr>
                    <?php
                        $jml += $bayar;
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th></th>
                    <th colspan="3">Total</th>
                    <th class="text-end"><?php echo e(rupiah($jml)); ?></th>
                    <th></th>
                </tr>
            </tbody>
        </table>

    </main>
</div>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.footerPrint','data' => []]); ?>
<?php $component->withName('footerPrint'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Temen\laravel-bimbel\resources\views/home/bayarReguler/bayarRegulerPrint.blade.php ENDPATH**/ ?>