

<?php $__env->startSection('main'); ?>
    <div class="modal fade" id="print" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false" role="dialog"
        aria-labelledby="modalTitleId" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable modal-lg my-3" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitleId">Laporan</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="/pembayaran-reguler/print" method="post" target="_blank">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <?php
                            inputText('awal', 'Tanggal awal', '', 'date', '');
                            inputText('akhir', 'Tanggal akhir', '', 'date', '');
                        ?>
                    </div>
                    <div class="modal-footer">
                        <button type="reset" class="btn btn-secondary">Reset</button>
                        <button type="submit" class="btn btn-primary">Print</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="row pasLayar">
        <div class="col-12">
            <div class="card shadow-sm">
                
                <div class="card-body table-responsive">
                    <?php if(session()->has('pesan')): ?>
                        <?php if (isset($component)) { $__componentOriginal338dcaad0951360b957e1d8e2e64f8056fbe8697 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Notif::class, ['pesan' => session('pesan')]); ?>
<?php $component->withName('notif'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal338dcaad0951360b957e1d8e2e64f8056fbe8697)): ?>
<?php $component = $__componentOriginal338dcaad0951360b957e1d8e2e64f8056fbe8697; ?>
<?php unset($__componentOriginal338dcaad0951360b957e1d8e2e64f8056fbe8697); ?>
<?php endif; ?>
                    <?php endif; ?>
                    
                    <div class="mb-3">
                        
                        <button type="button" class="btn btn-primary" title="Tambah data" data-bs-toggle="modal"
                            data-bs-target="#new">
                            <i class="bi bi-bookmark-plus"></i> Tambah
                        </button>
                        
                        <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#print"
                            title="Cetak laporan">
                            <i class="bi bi-printer-fill"></i> Print
                        </button>
                    </div>

                    
                    <div class="modal fade" id="new" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false"
                        role="dialog" aria-labelledby="modalTitleId" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-scrollable modal-lg my-3" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="modalTitleId">Tambah data</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <form action="/pembayaran-reguler" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="modal-body modalCustom">
                                        <?php if($errors->any() && !old('id')): ?>
                                            <?php
                                                notifFailed($errors->all());
                                                $tgl_bayar = old('tgl_bayar');
                                                // $no_kwitansi = old('no_kwitansi');
                                                $periode_awal = old('periode_awal');
                                                $id_bimbel_reguler = old('id_bimbel_reguler');
                                                $id_pelajar = old('id_pelajar');
                                            ?>
                                        <?php else: ?>
                                            <?php
                                                $tgl_bayar = '';
                                                // $no_kwitansi = '';
                                                $periode_awal = '';
                                                $id_bimbel_reguler = '';
                                                $id_pelajar = '';
                                            ?>
                                        <?php endif; ?>

                                        <?php
                                            inputText('tgl_bayar', 'Tanggal pembayaran', $tgl_bayar, 'date');
                                            // inputText('no_kwitansi', 'No. kwitansi', $no_kwitansi);
                                        ?>
                                        <div class="form-floating mb-3">
                                            <select class="form-select" name="id_pelajar" id="id_pelajar"
                                                aria-label="Floating label select example">
                                                <?php $__currentLoopData = $pelajar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php echo e($id_pelajar == $item->id_pelajar ? 'selected' : ''); ?>

                                                        value="<?php echo e($item->id_pelajar); ?>">
                                                        <?php echo e('Nama : ' . $item->nama . ' | Kelas : ' . $item->kelas); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <label for="id_pelajar">Pelajar</label>
                                        </div>
                                        <?php
                                            inputText('periode_awal', 'Periode awal', $periode_awal, 'date');
                                        ?>
                                        <div class="form-floating mb-3">
                                            <select class="form-select" name="id_bimbel_reguler" id="id_bimbel_reguler"
                                                aria-label="Floating label select example">
                                                <?php $__currentLoopData = $reguler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option
                                                        <?php echo e($id_bimbel_reguler == $item->id_bimbel_reguler ? 'selected' : ''); ?>

                                                        value="<?php echo e($item->id_bimbel_reguler); ?>">
                                                        <?php echo e('Kelas : ' . $item->kelas . ' pertemuan ' . $item->jumlah_pertemuan . 'x'); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <label for="id_bimbel_reguler">Paket bimbel</label>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="reset" class="btn btn-secondary">Reset</button>
                                        <button type="Submit" class="btn btn-primary">Simpan</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <table id="cekTabel" class="table table-nowrap table-centered rounded table-bordered border-dark">
                        <thead class="bg-primary">
                            <tr>
                                <th class="text-white">No</th>
                                <th class="text-white">Tanggal</th>
                                <th class="text-white">Kwitansi</th>
                                <th class="text-white">Pelajar</th>
                                <th class="text-white">Biaya</th>
                                <th class="text-white">Periode</th>
                                
                                <th class="text-white">Pilihan</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                    <td class="text-center"><?php echo e(tanggal($p->tgl_bayar)); ?></td>
                                    <td><?php echo e($p->no_kwitansi); ?></td>
                                    <td><?php echo e($p->nama); ?> </td>
                                    <td class="text-end"><?php echo e(rupiah($p->biaya)); ?> </td>
                                    <td class="text-center">
                                        <?php echo e(tanggal($p->periode_awal) . ' - ' . bulanDepan($p->periode_awal)); ?></td>
                                    
                                    <td>
                                        
                                        <button type="button" class="btn btn-warning" title="Edit data"
                                            data-bs-toggle="modal" data-bs-target="#edit<?php echo e($p->id_bayar_reguler); ?>">
                                            <i class="bi bi-pencil-square"></i>
                                        </button>
                                        
                                        <div class="modal fade" id="edit<?php echo e($p->id_bayar_reguler); ?>" tabindex="-1"
                                            data-bs-backdrop="static" data-bs-keyboard="false" role="dialog"
                                            aria-labelledby="modalTitleId" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-scrollable modal-lg my-3"
                                                role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="modalTitleId">Edit data</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <form action="/pembayaran-reguler/<?php echo e($p->id_bayar_reguler); ?>"
                                                        method="post">
                                                        <?php echo method_field('put'); ?>
                                                        <?php echo csrf_field(); ?>
                                                        <div class="modal-body modalCustom">
                                                            <input type="hidden" name="id"
                                                                value="<?php echo e($p->id_bayar_reguler); ?>">
                                                            <?php if($errors->any() && old('id') == $p->id_bayar_reguler): ?>
                                                                <?php
                                                                    notifFailed($errors->all());
                                                                    $tgl_bayar = old('tgl_bayar');
                                                                    // $no_kwitansi = old('no_kwitansi');
                                                                    $periode_awal = old('periode_awal');
                                                                    $id_bimbel_reguler = old('id_bimbel_reguler');
                                                                    $id_pelajar = old('id_pelajar');
                                                                ?>
                                                            <?php else: ?>
                                                                <?php
                                                                    $tgl_bayar = $p->tgl_bayar;
                                                                    // $no_kwitansi = $p->no_kwitansi;
                                                                    $periode_awal = $p->periode_awal;
                                                                    $id_bimbel_reguler = $p->id_bimbel_reguler;
                                                                    $id_pelajar = $p->id_pelajar;
                                                                ?>
                                                            <?php endif; ?>

                                                            <?php
                                                                inputText('tgl_bayar', 'Tanggal pembayaran', $tgl_bayar, 'date');
                                                                // inputText('no_kwitansi', 'No. kwitansi', $no_kwitansi);
                                                            ?>
                                                            <div class="form-floating mb-3">
                                                                <select class="form-select" name="id_pelajar"
                                                                    id="id_pelajar"
                                                                    aria-label="Floating label select example">
                                                                    <?php $__currentLoopData = $pelajar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option
                                                                            <?php echo e($id_pelajar == $item->id_pelajar ? 'selected' : ''); ?>

                                                                            value="<?php echo e($item->id_pelajar); ?>">
                                                                            <?php echo e('Nama : ' . $item->nama . ' | Kelas : ' . $item->kelas); ?>

                                                                        </option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                                <label for="id_pelajar">Pelajar</label>
                                                            </div>
                                                            <?php
                                                                inputText('periode_awal', 'Periode awal', $periode_awal, 'date');
                                                            ?>
                                                            <div class="form-floating mb-3">
                                                                <select class="form-select" name="id_bimbel_reguler"
                                                                    id="id_bimbel_reguler"
                                                                    aria-label="Floating label select example">
                                                                    <?php $__currentLoopData = $reguler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option
                                                                            <?php echo e($id_bimbel_reguler == $item->id_bimbel_reguler ? 'selected' : ''); ?>

                                                                            value="<?php echo e($item->id_bimbel_reguler); ?>">
                                                                            <?php echo e('Kelas : ' . $item->kelas . ' pertemuan ' . $item->jumlah_pertemuan . 'x'); ?>

                                                                        </option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                                <label for="id_bimbel_reguler">Paket bimbel</label>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="reset"
                                                                class="btn btn-secondary">Reset</button>
                                                            <button type="Submit" class="btn btn-primary">Update</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <form action="/pembayaran-reguler/<?php echo e($p->id_bayar_reguler); ?>" method="post"
                                            class="d-inline">
                                            <?php echo method_field('delete'); ?>
                                            <?php echo csrf_field(); ?>
                                            <button title="Hapus data" class="btn btn-danger show_confirm"><i
                                                    class="bi bi-trash-fill"></i></button>
                                        </form>
                                        <a href="/pembayaran-reguler/kwitansi/<?php echo e($p->id_bayar_reguler); ?>" target="_blank"
                                            class="btn btn-success" title="Cetak kwitansi"><i
                                                class="bi bi-file-earmark-text-fill"></i></a>
                                    </td>
                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home/layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Temen\laravel-bimbel\resources\views/home/bayarReguler/bayarReguler.blade.php ENDPATH**/ ?>