<footer>
    <!-- place footer here -->
</footer>

<script>
    const cetak = document.getElementById('print')
    cetak.addEventListener('click', () => {
        window.print()
    })
</script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\Temen\laravel-bimbel\resources\views/components/footerPrint.blade.php ENDPATH**/ ?>