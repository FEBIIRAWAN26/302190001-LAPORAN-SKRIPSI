<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.headerPrint','data' => ['title' => ''.e($title).'']]); ?>
<?php $component->withName('headerPrint'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => ''.e($title).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<style>
    .bg-gambar {
        background-image: url(/img/bg-logo.png);
        /* Ganti dengan path ke logo Anda */
        background-size: contain;
        background-repeat: no-repeat;
        background-position: center;
        /* Transparansi 50% (0.5) */
        padding: 20px;
    }

    .text-12 {
        font-size: 12px;
    }
</style>
<div class="container">
    <div class="border border-1 border-dark mt-2 wadah">
        <header class="position-relative">
            <img src="/img/blc-logo.png" width="75px" alt="Logo BLC" class="position-absolute logo-30">
            <div class="position-absolute end-0" style="top: 25px">
                <main>
                    <table class="teble table-bordered">
                        <tr>
                            <td class="text-center">
                                <b class="border-bottom border-dark">BUKTI PEMBAYARAN</b>
                                <br>
                                No. Kwitansi
                                <br>
                                <?php echo e($data->no_kwitansi); ?>

                            </td>
                        </tr>
                    </table>
                </main>
            </div>
            <div class="text-center p-0">
                <main>
                    <p class="m-0">Bimbingan Belajar</p>
                </main>
                <h2 class="m-0">BRILLIANT LEARNING CENTER</h2>
                <main>
                    <P class="text-sm-center m-0">
                        Jl. Cicukang Rt 02/28 Ds. Mekarrahayu Kec. Margaasih Kab. Bandung 40218<br> <i
                            class="bi bi-chat-dots-fill"></i> 0855721064363 <i class="bi bi-chat-left-dots-fill"></i>
                        D010ABB6
                        <i class="bi bi-chat-left-text-fill"></i> brilliant_blc <i class="bi bi-envelope-at-fill"></i>
                        brilliantblc2013@gmail.com<br>
                        <b>BNI : 0257636907 BRI : 399801009816537</b>
                    </P>
                </main>
            </div>
        </header>
        <div class="border-top border-2 border-dark"></div>
        <main class="bg-gambar py-0 m-0">
            <table>
                <tr>
                    <td width="30%" class="align-top">
                        
                        <br>
                        Nama
                        <br>
                        Pencatat
                        <br>
                        Jumlah
                        <br>
                        Terbilang
                        <br>
                        Keterangan
                    </td>
                    <td width="35%" class="align-top">
                        
                        <br>
                        : <?php echo e($data->pelajar->nama); ?>

                        <br>
                        : <?php echo e($data->pengguna->nama); ?>

                        <br>
                        :
                        <?php echo e(rupiah($data->reguler->biaya)); ?>

                        <br>
                        :
                        <?php echo e(ucwords(uangText($data->reguler->biaya))); ?>

                        <br>
                    </td>
                    <td width="15%" class="align-top">
                        No. Record
                        <br>
                        Kelas
                        <br>
                        Jenis pembayaran
                    </td>
                    <td width="25%" class="align-top">
                        :
                        <br>
                        : <?php echo e($data->pelajar->kelas); ?>

                        <br>
                        : <?php echo e($jenis); ?>

                    </td>
                </tr>
                <tr>
                    <td colspan="2" class="align-top">
                        <p class="border-dark border py-2 text-center text-bold">Bimbel reguler pada tanggal : <br>
                            <?php echo e(tanggal($data->periode_awal) . ' - ' . bulanDepan($data->periode_awal)); ?></p>
                        <p class="mt-5">Catatan :<br><i>*Biaya yang telah dibayar tidak dapat diambil
                                kembali</i></p>
                    </td>
                    <td colspan="2" class="text-center align-top">
                        Tanggal : <?php echo e(date('d M Y')); ?><br>Penerima
                        <p class="text-center" style="margin-top: 70px">
                            (................................................................)</p>
                    </td>
                </tr>
            </table>
        </main>
    </div>
</div>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.footerPrint','data' => []]); ?>
<?php $component->withName('footerPrint'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Temen\laravel-bimbel\resources\views/home/bayarReguler/bayarRegulerKwintansi.blade.php ENDPATH**/ ?>