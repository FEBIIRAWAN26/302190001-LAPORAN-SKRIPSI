

<?php $__env->startSection('main'); ?>
    <div class="row pasLayar">
        <div class="col-12">
            <div class="card shadow-sm">
                
                <div class="card-body table-responsive">
                    <?php if(session()->has('gagal')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            <b><i class="bi bi-exclamation-triangle-fill"></i></b> <?php echo e(session('gagal')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session()->has('pesan')): ?>
                        <?php if (isset($component)) { $__componentOriginal338dcaad0951360b957e1d8e2e64f8056fbe8697 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Notif::class, ['pesan' => session('pesan')]); ?>
<?php $component->withName('notif'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal338dcaad0951360b957e1d8e2e64f8056fbe8697)): ?>
<?php $component = $__componentOriginal338dcaad0951360b957e1d8e2e64f8056fbe8697; ?>
<?php unset($__componentOriginal338dcaad0951360b957e1d8e2e64f8056fbe8697); ?>
<?php endif; ?>
                    <?php endif; ?>
                    <!-- Modal trigger button -->
                    
                    <button type="button" class="btn btn-primary mb-3" title="Tambah data" data-bs-toggle="modal"
                        data-bs-target="#new">
                        <i class="bi bi-bookmark-plus"></i> Tambah
                    </button>
                    
                    
                    <div class="modal fade" id="new" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false"
                        role="dialog" aria-labelledby="modalTitleId" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-scrollable modal-lg my-3" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="modalTitleId">Tambah data</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <form action="/bimbel-private" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="modal-body modalCustom">
                                        <?php if($errors->any() && !old('id')): ?>
                                            <?php
                                                notifFailed($errors->all());
                                                $paket_siswa = old('paket_siswa');
                                                $tingkat_sekolah = old('tingkat_sekolah');
                                                $biaya = old('biaya');
                                                $jumlah_pertemuan = old('jumlah_pertemuan');
                                            ?>
                                        <?php else: ?>
                                            <?php
                                                $paket_siswa = '';
                                                $tingkat_sekolah = '';
                                                $biaya = '';
                                                $jumlah_pertemuan = '';
                                            ?>
                                        <?php endif; ?>
                                        <?php
                                            inputText('paket_siswa', 'Jumlah/paket siswa', $paket_siswa, 'number');
                                            inputText('tingkat_sekolah', 'Tingkat sekolah', $tingkat_sekolah);
                                            inputText('biaya', 'Biaya bimbel', $biaya, 'number');
                                            inputText('jumlah_pertemuan', 'Jumlah pertemuan', $jumlah_pertemuan, 'number');
                                        ?>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="reset" class="btn btn-secondary">Reset</button>
                                        <button type="Submit" class="btn btn-primary">Simpan</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <table id="cekTabel" class="table table-nowrap table-centered rounded table-bordered border-dark">
                        <thead class="bg-primary">
                            <tr>
                                <th class="text-white">No</th>
                                <th class="text-white">Jumlah/paket siswa</th>
                                <th class="text-white">Tingkat sekolah</th>
                                <th class="text-white">Biaya bimbel</th>
                                <th class="text-white">Pertemuan</th>
                                <th class="text-white">Biaya/pertemuan</th>
                                
                                <th class="text-white">Pilihan</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                    <td class="text-center"><?php echo e($p->paket_siswa); ?></td>
                                    <td><?php echo e($p->tingkat_sekolah); ?></td>
                                    <td class="text-end"><?php echo e(rupiah($p->biaya)); ?></td>
                                    <td class="text-center"><?php echo e($p->jumlah_pertemuan); ?> x</td>
                                    <td class="text-end"><?php echo e(rupiah($p->biaya / $p->jumlah_pertemuan)); ?>/1x</td>
                                    
                                    <td>
                                        <button type="button" class="btn btn-warning me-2" data-bs-toggle="modal"
                                            data-bs-target="#edit<?php echo e($p->id_bimbel_private); ?>">
                                            <i class="bi bi-pencil-square"></i>
                                        </button>
                                        
                                        <div class="modal fade" id="edit<?php echo e($p->id_bimbel_private); ?>" tabindex="-1"
                                            data-bs-backdrop="static" data-bs-keyboard="false" role="dialog"
                                            aria-labelledby="modalTitleId" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-scrollable modal-lg my-3" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="modalTitleId">Edit data</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <form action="/bimbel-private/<?php echo e($p->id_bimbel_private); ?>"
                                                        method="post">
                                                        <?php echo method_field('put'); ?>
                                                        <?php echo csrf_field(); ?>
                                                        <div class="modal-body modalCustom">
                                                            <input type="hidden" name="id"
                                                                value="<?php echo e($p->id_bimbel_private); ?>">
                                                            <?php if($errors->any() && old('id') == $p->id_bimbel_private): ?>
                                                                <?php
                                                                    notifFailed($errors->all());
                                                                    $paket_siswa = old('paket_siswa');
                                                                    $tingkat_sekolah = old('tingkat_sekolah');
                                                                    $biaya = old('biaya');
                                                                    $jumlah_pertemuan = old('jumlah_pertemuan');
                                                                ?>
                                                            <?php else: ?>
                                                                <?php
                                                                    $paket_siswa = $p->paket_siswa;
                                                                    $tingkat_sekolah = $p->tingkat_sekolah;
                                                                    $biaya = $p->biaya;
                                                                    $jumlah_pertemuan = $p->jumlah_pertemuan;
                                                                ?>
                                                            <?php endif; ?>

                                                            <?php
                                                                inputText('paket_siswa', 'Jumlah/paket siswa', $paket_siswa, 'number');
                                                                inputText('tingkat_sekolah', 'Tingkat sekolah', $tingkat_sekolah);
                                                                inputText('biaya', 'Biaya bimbel', $biaya, 'number');
                                                                inputText('jumlah_pertemuan', 'Jumlah pertemuan', $jumlah_pertemuan, 'number');
                                                            ?>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="reset" class="btn btn-secondary">Reset</button>
                                                            <button type="Submit" class="btn btn-primary">Update</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                        <form action="/bimbel-private/<?php echo e($p->id_bimbel_private); ?>" method="post"
                                            class="d-inline">
                                            <?php echo method_field('delete'); ?>
                                            <?php echo csrf_field(); ?>
                                            <button title="Hapus data" class="btn btn-danger show_confirm"><i
                                                    class="bi bi-trash-fill"></i></button>
                                        </form>
                                    </td>
                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Temen\laravel-bimbel\resources\views/home/bimbelPrivate/bimbelPrivate.blade.php ENDPATH**/ ?>