<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CAuth;
use App\Http\Controllers\CBayarPrivate;
use App\Http\Controllers\CBayarReguler;
use App\Http\Controllers\CBimbelPrivate;
use App\Http\Controllers\CBimbelReguler;
use App\Http\Controllers\CHome;
use App\Http\Controllers\CPengguna;
use App\Http\Controllers\CPelajar;
/*
|--------------------------------------------------------------------------`
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/laravel', function () {
    return view('welcome');
});
// Route::get('/', function () {
//     return view('login');
// });

Route::controller(CAuth::class)->group(function () {
    Route::get('/', 'index')->name('login')->middleware('guest');
    Route::post('/login', 'authenticate');
    Route::post('/logout', 'logout');
});

// Route::get('/pelajar/{mPelajar}/edit', [CPelajar::class, 'edit'])->middleware('auth');

Route::middleware('auth')->group(function () {
    Route::group(['middleware' => ['status:manajer,owner,admin']], function () {
        Route::get('/dashboard', [CHome::class, 'index'])->name('dashboard');
        Route::post('/pembayaran-private/print', [CBayarPrivate::class, 'print']);
        Route::post('/pembayaran-reguler/print', [CBayarReguler::class, 'print']);
        Route::get('/pembayaran-private/pertemuan/{id}', [CBayarPrivate::class, 'pertemuan']);
        Route::get('/pembayaran-reguler', [CBayarReguler::class, 'index']);
        Route::get('/pembayaran-private', [CBayarPrivate::class, 'index']);

        Route::resource('/bimbel-reguler', CBimbelReguler::class)->except('create', 'show', 'edit');
        Route::resource('/bimbel-private', CBimbelPrivate::class)->except('create', 'show', 'edit');
        Route::resource('/pembayaran-reguler', CBayarReguler::class)->except('create', 'show', 'edit');
        Route::resource('/pembayaran-private', CBayarPrivate::class)->except('create', 'show', 'edit');

        Route::delete('/pembayaran-private/pertemuan/{id}', [CBayarPrivate::class, 'pertemuanDelete']);
        Route::get('/pembayaran-private/pertemuan/{id}/store', [CBayarPrivate::class, 'pertemuanCreate']);
        Route::get('/pembayaran-private/kwitansi/{id}', [CBayarPrivate::class, 'kwitansi']);
        Route::get('/pembayaran-reguler/kwitansi/{id}', [CBayarReguler::class, 'kwitansi']);

        Route::group(['middleware' => ['status:manajer,owner']], function () {
            // Route::get('/pelajar', [CPelajar::class, 'index']);
            // Route::get('/bimbel-reguler', [CBimbelReguler::class, 'index']);
            // Route::get('/bimbel-private', [CBimbelPrivate::class, 'index']);

            Route::resource('/pelajar', CPelajar::class)->except('create', 'show', 'edit');
            Route::resource('/pengguna', CPengguna::class)->except('create', 'show', 'edit');
        });
        // Route::group(['middleware' => ['status:admin,staff keuangan']], function () {
        // });
        // Route::group(['middleware' => 'admin'], function () {
    });
});
