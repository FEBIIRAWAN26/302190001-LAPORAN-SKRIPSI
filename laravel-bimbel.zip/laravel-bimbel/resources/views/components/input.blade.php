{{-- @props(['pesan']) --}}

<div class="form-floating mb-3">
    <input type="<?= isset($type) ? $type : 'text' ?>" name="<?= $name ?>" placeholder="<?= $label ?>"
        minlength="<?= isset($minL) ? $minL : '' ?>" maxlength="<?= isset($maxL) ? $maxL : '' ?>"
        min="{{ isset($min) ? $min : '' }}" max="{{ isset($max) ? $max : '' }}" autofocus <?= isset($req) ? $req : '' ?>
        class="form-control" id="<?= $name ?>" value="<?= isset($val) ? $val : '' ?>">
    <label for="<?= $name ?>"><?= $label ?></label>
</div>
