<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="/css/volt.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.4/font/bootstrap-icons.css">
    <link rel="stylesheet" href="/css/style.css">
    <title>Login</title>
</head>

<body>
    <main>
        <section class="vh-lg-100 mt-5 mt-lg-0 bg-soft d-flex align-items-center">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-5">
                        @if (session()->has('gagal'))
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <i class="bi bi-exclamation-triangle-fill"></i> {{ session('gagal') }}
                                <button type="button" class="btn-close" data-bs-dismiss="alert"
                                    aria-label="Close"></button>
                            </div>
                        @endif
                    </div>
                </div>
                <div class="row justify-content-center form-bg-image"
                    data-background-lg="https://nusagama.com/wp-content/uploads/2019/02/nusagama-les.png">
                    {{-- <h1>{{ uangText(10000000) . ' rupiah' }}</h1> --}}
                    <div class="col-5 d-flex align-items-center justify-content-center">
                        <div class="bg-white shadow border-0 rounded border-light p-5 w-100 fmxw-500">
                            <div class="text-center text-md-center">
                                <img src="/img/blc-logo.png" alt="Logo BLC" height="100px">
                            </div>
                            {{-- <div class="border-top border-dark"></div> --}}
                            <form action="/login" method="post" class="">
                                @csrf
                                <div class="form-group mb-4">
                                    <label for="username">Username</label>
                                    <div class="input-group">
                                        <span for="username" class="input-group-text">
                                            <i class="bi bi-person-fill"></i>
                                        </span>
                                        <input type="text" name="username" class="form-control"
                                            placeholder="Username" autofocus id="username" autofocus required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="form-group mb-4">
                                        <label for="password">Password</label>
                                        <div class="input-group">
                                            <span class="input-group-text" id="basic-addon2">
                                                <i class="bi bi-person-fill-lock"></i>
                                            </span>
                                            <input type="password" name="password" placeholder="Password"
                                                class="form-control" id="password" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-primary">Login</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <script src="/js/bootstrap.js"></script>
</body>

</html>
