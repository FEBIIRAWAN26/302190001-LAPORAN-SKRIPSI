<div class="sidebar-inner px-4 pt-3">
    <ul class="nav flex-column pt-3 pt-md-0">
        <li class="nav-item {{ Request::is('dashboard*') ? 'active' : '' }}">
            <a href="/dashboard" class="nav-link">
                <span class="sidebar-text"><i class="bi bi-layout-wtf"></i> Dashboard</span>
            </a>
        </li>
        @if (auth()->user()->status == 'manajer' || auth()->user()->status == 'owner')
            <li class="nav-item {{ Request::is('pelajar*') ? 'active' : '' }}">
                <a href="/pelajar" class="nav-link">
                    <span class="sidebar-text"><i class="bi bi-people-fill"></i> Pelajar</span>
                </a>
            </li>
        @endif

        <li class="nav-item">
            <span class="nav-link collapsed d-flex justify-content-between align-items-center" data-bs-toggle="collapse"
                data-bs-target="#pembayaran">
                <span>
                    <span class="sidebar-text"><i class="bi bi-cash-stack"></i> Pembayaran</span>
                </span>
                <span class="link-arrow">
                    <i class="bi bi-chevron-right"></i>
                </span>
            </span>
            <div class="ms-3 collapse" role="list" id="pembayaran" aria-expanded="false">
                <ul class="flex-column nav">
                    <li class="nav-item  {{ Request::is('pembayaran-reguler*') ? 'active' : '' }}">
                        <a href="/pembayaran-reguler" class="nav-link">
                            <span class="sidebar-text"><i class="bi bi-r-circle-fill"></i> Reguler</span>
                        </a>
                    </li>
                    <li class="nav-item {{ Request::is('pembayaran-private*') ? 'active' : '' }}">
                        <a href="/pembayaran-private" class="nav-link">
                            <span class="sidebar-text"><i class="bi bi-file-earmark-person-fill"></i> Private</span>
                        </a>
                    </li>
                </ul>
            </div>
        </li>
        {{-- 
        @if (auth()->user()->status == 'admin' || auth()->user()->status == 'owner') --}}
        <li class="nav-item">
            <span class="nav-link collapsed d-flex justify-content-between align-items-center" data-bs-toggle="collapse"
                data-bs-target="#program">
                <span>
                    <span class="sidebar-text"><i class="bi bi-collection-fill"></i> Program</span>
                </span>
                <span class="link-arrow">
                    <i class="bi bi-chevron-right"></i>
                </span>
            </span>
            <div class="ms-3 collapse" role="list" id="program" aria-expanded="false">
                <ul class="flex-column nav">
                    <li class="nav-item {{ Request::is('bimbel-reguler*') ? 'active' : '' }}">
                        <a href="/bimbel-reguler" class="nav-link">
                            <span class="sidebar-text"><i class="bi bi-r-circle-fill"></i> Reguler</span>
                        </a>
                    </li>
                    <li class="nav-item {{ Request::is('bimbel-private*') ? 'active' : '' }}">
                        <a href="/bimbel-private" class="nav-link">
                            <span class="sidebar-text"><i class="bi bi-file-earmark-person-fill"></i> Private</span>
                        </a>
                    </li>
                </ul>
            </div>
        </li>
        {{-- @endif --}}
        {{-- @can('admin') --}}
        @if (auth()->user()->status == 'owner' || auth()->user()->status == 'manajer')
            <li class="nav-item  {{ Request::is('pengguna*') ? 'active' : '' }}">
                <a href="/pengguna" class="nav-link">
                    <span class="sidebar-text"><i class="bi bi-person-fill"></i> Pengguna</span>
                </a>
            </li>
        @endif
        {{-- @endcan --}}

    </ul>
</div>
