@extends('home/layout/layout')

@section('main')
    <div class="modal fade" id="print" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false" role="dialog"
        aria-labelledby="modalTitleId" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable modal-lg my-3" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitleId">Laporan</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="/pembayaran-reguler/print" method="post" target="_blank">
                    @csrf
                    <div class="modal-body">
                        @php
                            inputText('awal', 'Tanggal awal', '', 'date', '');
                            inputText('akhir', 'Tanggal akhir', '', 'date', '');
                        @endphp
                    </div>
                    <div class="modal-footer">
                        <button type="reset" class="btn btn-secondary">Reset</button>
                        <button type="submit" class="btn btn-primary">Print</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="row pasLayar">
        <div class="col-12">
            <div class="card shadow-sm">
                {{-- <div class="card-header text-center  pt-3">
                    <h4 id="cekk">Tabel data</h4>
                </div> --}}
                <div class="card-body table-responsive">
                    @if (session()->has('pesan'))
                        <x-notif :pesan="session('pesan')" />
                    @endif
                    {{-- <a class="btn btn-primary mb-3" title="Tambah data" href="/pembayaran-reguler/create" role="button"><i
                            class="bi bi-bookmark-plus"></i> Tambah</a> --}}
                    <div class="mb-3">
                        {{-- @if (auth()->user()->status == 'admin' || auth()->user()->status == 'staff keuangan') --}}
                        <button type="button" class="btn btn-primary" title="Tambah data" data-bs-toggle="modal"
                            data-bs-target="#new">
                            <i class="bi bi-bookmark-plus"></i> Tambah
                        </button>
                        {{-- @endif --}}
                        <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#print"
                            title="Cetak laporan">
                            <i class="bi bi-printer-fill"></i> Print
                        </button>
                    </div>

                    {{-- tambah data --}}
                    <div class="modal fade" id="new" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false"
                        role="dialog" aria-labelledby="modalTitleId" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-scrollable modal-lg my-3" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="modalTitleId">Tambah data</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <form action="/pembayaran-reguler" method="post">
                                    @csrf
                                    <div class="modal-body modalCustom">
                                        @if ($errors->any() && !old('id'))
                                            @php
                                                notifFailed($errors->all());
                                                $tgl_bayar = old('tgl_bayar');
                                                // $no_kwitansi = old('no_kwitansi');
                                                $periode_awal = old('periode_awal');
                                                $id_bimbel_reguler = old('id_bimbel_reguler');
                                                $id_pelajar = old('id_pelajar');
                                            @endphp
                                        @else
                                            @php
                                                $tgl_bayar = '';
                                                // $no_kwitansi = '';
                                                $periode_awal = '';
                                                $id_bimbel_reguler = '';
                                                $id_pelajar = '';
                                            @endphp
                                        @endif

                                        @php
                                            inputText('tgl_bayar', 'Tanggal pembayaran', $tgl_bayar, 'date');
                                            // inputText('no_kwitansi', 'No. kwitansi', $no_kwitansi);
                                        @endphp
                                        <div class="form-floating mb-3">
                                            <select class="form-select" name="id_pelajar" id="id_pelajar"
                                                aria-label="Floating label select example">
                                                @foreach ($pelajar as $item)
                                                    <option {{ $id_pelajar == $item->id_pelajar ? 'selected' : '' }}
                                                        value="{{ $item->id_pelajar }}">
                                                        {{ 'Nama : ' . $item->nama . ' | Kelas : ' . $item->kelas }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            <label for="id_pelajar">Pelajar</label>
                                        </div>
                                        @php
                                            inputText('periode_awal', 'Periode awal', $periode_awal, 'date');
                                        @endphp
                                        <div class="form-floating mb-3">
                                            <select class="form-select" name="id_bimbel_reguler" id="id_bimbel_reguler"
                                                aria-label="Floating label select example">
                                                @foreach ($reguler as $item)
                                                    <option
                                                        {{ $id_bimbel_reguler == $item->id_bimbel_reguler ? 'selected' : '' }}
                                                        value="{{ $item->id_bimbel_reguler }}">
                                                        {{ 'Kelas : ' . $item->kelas . ' pertemuan ' . $item->jumlah_pertemuan . 'x' }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            <label for="id_bimbel_reguler">Paket bimbel</label>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="reset" class="btn btn-secondary">Reset</button>
                                        <button type="Submit" class="btn btn-primary">Simpan</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <table id="cekTabel" class="table table-nowrap table-centered rounded table-bordered border-dark">
                        <thead class="bg-primary">
                            <tr>
                                <th class="text-white">No</th>
                                <th class="text-white">Tanggal</th>
                                <th class="text-white">Kwitansi</th>
                                <th class="text-white">Pelajar</th>
                                <th class="text-white">Biaya</th>
                                <th class="text-white">Periode</th>
                                {{-- @if (auth()->user()->status == 'admin' || auth()->user()->status == 'staff keuangan') --}}
                                <th class="text-white">Pilihan</th>
                                {{-- @endif --}}
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($data as $p)
                                <tr>
                                    <td class="text-center">{{ $loop->iteration }}</td>
                                    <td class="text-center">{{ tanggal($p->tgl_bayar) }}</td>
                                    <td>{{ $p->no_kwitansi }}</td>
                                    <td>{{ $p->nama }} </td>
                                    <td class="text-end">{{ rupiah($p->biaya) }} </td>
                                    <td class="text-center">
                                        {{ tanggal($p->periode_awal) . ' - ' . bulanDepan($p->periode_awal) }}</td>
                                    {{-- @if (auth()->user()->status == 'admin' || auth()->user()->status == 'staff keuangan') --}}
                                    <td>
                                        {{-- <a href="/pembayaran-reguler/{{ $p->id_bayar_reguler }}/edit" title="Edit data"
                                            class="btn btn-warning "><i class="bi bi-pencil-square"></i></a> --}}
                                        <button type="button" class="btn btn-warning" title="Edit data"
                                            data-bs-toggle="modal" data-bs-target="#edit{{ $p->id_bayar_reguler }}">
                                            <i class="bi bi-pencil-square"></i>
                                        </button>
                                        {{-- edit --}}
                                        <div class="modal fade" id="edit{{ $p->id_bayar_reguler }}" tabindex="-1"
                                            data-bs-backdrop="static" data-bs-keyboard="false" role="dialog"
                                            aria-labelledby="modalTitleId" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-scrollable modal-lg my-3"
                                                role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="modalTitleId">Edit data</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <form action="/pembayaran-reguler/{{ $p->id_bayar_reguler }}"
                                                        method="post">
                                                        @method('put')
                                                        @csrf
                                                        <div class="modal-body modalCustom">
                                                            <input type="hidden" name="id"
                                                                value="{{ $p->id_bayar_reguler }}">
                                                            @if ($errors->any() && old('id') == $p->id_bayar_reguler)
                                                                @php
                                                                    notifFailed($errors->all());
                                                                    $tgl_bayar = old('tgl_bayar');
                                                                    // $no_kwitansi = old('no_kwitansi');
                                                                    $periode_awal = old('periode_awal');
                                                                    $id_bimbel_reguler = old('id_bimbel_reguler');
                                                                    $id_pelajar = old('id_pelajar');
                                                                @endphp
                                                            @else
                                                                @php
                                                                    $tgl_bayar = $p->tgl_bayar;
                                                                    // $no_kwitansi = $p->no_kwitansi;
                                                                    $periode_awal = $p->periode_awal;
                                                                    $id_bimbel_reguler = $p->id_bimbel_reguler;
                                                                    $id_pelajar = $p->id_pelajar;
                                                                @endphp
                                                            @endif

                                                            @php
                                                                inputText('tgl_bayar', 'Tanggal pembayaran', $tgl_bayar, 'date');
                                                                // inputText('no_kwitansi', 'No. kwitansi', $no_kwitansi);
                                                            @endphp
                                                            <div class="form-floating mb-3">
                                                                <select class="form-select" name="id_pelajar"
                                                                    id="id_pelajar"
                                                                    aria-label="Floating label select example">
                                                                    @foreach ($pelajar as $item)
                                                                        <option
                                                                            {{ $id_pelajar == $item->id_pelajar ? 'selected' : '' }}
                                                                            value="{{ $item->id_pelajar }}">
                                                                            {{ 'Nama : ' . $item->nama . ' | Kelas : ' . $item->kelas }}
                                                                        </option>
                                                                    @endforeach
                                                                </select>
                                                                <label for="id_pelajar">Pelajar</label>
                                                            </div>
                                                            @php
                                                                inputText('periode_awal', 'Periode awal', $periode_awal, 'date');
                                                            @endphp
                                                            <div class="form-floating mb-3">
                                                                <select class="form-select" name="id_bimbel_reguler"
                                                                    id="id_bimbel_reguler"
                                                                    aria-label="Floating label select example">
                                                                    @foreach ($reguler as $item)
                                                                        <option
                                                                            {{ $id_bimbel_reguler == $item->id_bimbel_reguler ? 'selected' : '' }}
                                                                            value="{{ $item->id_bimbel_reguler }}">
                                                                            {{ 'Kelas : ' . $item->kelas . ' pertemuan ' . $item->jumlah_pertemuan . 'x' }}
                                                                        </option>
                                                                    @endforeach
                                                                </select>
                                                                <label for="id_bimbel_reguler">Paket bimbel</label>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="reset"
                                                                class="btn btn-secondary">Reset</button>
                                                            <button type="Submit" class="btn btn-primary">Update</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <form action="/pembayaran-reguler/{{ $p->id_bayar_reguler }}" method="post"
                                            class="d-inline">
                                            @method('delete')
                                            @csrf
                                            <button title="Hapus data" class="btn btn-danger show_confirm"><i
                                                    class="bi bi-trash-fill"></i></button>
                                        </form>
                                        <a href="/pembayaran-reguler/kwitansi/{{ $p->id_bayar_reguler }}" target="_blank"
                                            class="btn btn-success" title="Cetak kwitansi"><i
                                                class="bi bi-file-earmark-text-fill"></i></a>
                                    </td>
                                    {{-- @endif --}}
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
