@extends('home/layout/layout')

@section('main')
    <div class="row ">
        <div class="col-12">
            <div class="card shadow-sm">
                {{-- <div class="card-header text-center  pt-3">
                    <h4 id="cekk">Tabel data</h4>
                </div> --}}
                <div class="card-body table-responsive">
                    @if (session()->has('pesan'))
                        <x-notif :pesan="session('pesan')" />
                    @endif
                    {{-- @can('admin') --}}
                    <button type="button" class="btn btn-primary mb-3" title="Tambah data" data-bs-toggle="modal"
                        data-bs-target="#new">
                        <i class="bi bi-bookmark-plus"></i> Tambah
                    </button>
                    {{-- @endcan --}}

                    {{-- tambah data --}}
                    <div class="modal fade" id="new" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false"
                        role="dialog" aria-labelledby="modalTitleId" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-scrollable modal-lg my-3" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="modalTitleId">Tambah data</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <form action="/pelajar" method="post">
                                    @csrf
                                    <div class="modal-body modalCustom">
                                        @if ($errors->any() && !old('id'))
                                            @php
                                                notifFailed($errors->all());
                                                $nama = old('nama');
                                                // $nis = old('nis');
                                                $kelas = old('kelas');
                                                $alamat = old('alamat');
                                                $telp = old('telp');
                                                $jk = old('jk');
                                            @endphp
                                        @else
                                            @php
                                                $nama = '';
                                                // $nis = '';
                                                $kelas = '';
                                                $alamat = '';
                                                $telp = '';
                                                $jk = '';
                                            @endphp
                                        @endif

                                        @php
                                            // inputText('nis', 'NIS', $nis);
                                        @endphp
                                        {{-- <input type="text" maxlength="2"> --}}
                                        <x-input :name="'nama'" :label="'Nama lengkap'" :req="'required'" :val="$nama" />
                                        @php
                                            // inputText('nama', 'Nama lengkap', $nama);
                                            inputText('kelas', 'Kelas ', $kelas);
                                            inputText('telp', 'Nomor telepon', $telp, 'number', 10, 15);
                                            inputText('alamat', 'Alamat', $alamat);
                                        @endphp
                                        <h6>Jenis kelamin</h6>
                                        @php
                                            inputRadio('jk', 'Laki-laki', 'L', $jk);
                                            inputRadio('jk', 'Perempuan', 'P', $jk);
                                        @endphp
                                    </div>
                                    <div class="modal-footer">
                                        <button type="reset" class="btn btn-secondary">Reset</button>
                                        <button type="Submit" class="btn btn-primary">Simpan</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <table id="cekTabel" class="table table-nowrap table-centered rounded table-bordered border-dark">
                        <thead class="bg-primary">
                            <tr>
                                <th class="text-white">No</th>
                                {{-- <th class="text-white">NIS</th> --}}
                                <th class="text-white">Nama</th>
                                <th class="text-white">Gender</th>
                                <th class="text-white">Kelas</th>
                                <th class="text-white">Alamat</th>
                                <th class="text-white">Telepon</th>
                                {{-- @can('admin') --}}
                                <th class="text-white">Pilihan</th>
                                {{-- @endcan --}}
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($pelajar as $p)
                                <tr>
                                    <td class="text-center">{{ $loop->iteration }}</td>
                                    {{-- <td>{{ $p->nis }}</td> --}}
                                    <td>{{ $p->nama }}</td>
                                    <td>{{ $p->jk }}</td>
                                    <td class="text-center">{{ $p->kelas }}</td>
                                    <td>{{ $p->alamat }}</td>
                                    <td>{{ $p->telp }}</td>
                                    {{-- @can('admin') --}}
                                    <td>
                                        {{-- <a href="/pelajar/{{ $p->id_pelajar }}/edit" title="Edit data"
                                            class="btn btn-warning "><i class="bi bi-pencil-square"></i></a> --}}
                                        <button type="button" class="btn btn-warning me-2" data-bs-toggle="modal"
                                            data-bs-target="#edit{{ $p->id_pelajar }}">
                                            <i class="bi bi-pencil-square"></i>
                                        </button>
                                        {{-- edit --}}
                                        <div class="modal fade" id="edit{{ $p->id_pelajar }}" tabindex="-1"
                                            data-bs-backdrop="static" data-bs-keyboard="false" role="dialog"
                                            aria-labelledby="modalTitleId" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-scrollable modal-lg my-3" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="modalTitleId">Edit data</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <form action="/pelajar/{{ $p->id_pelajar }}" method="post">
                                                        @method('put')
                                                        @csrf
                                                        <div class="modal-body modalCustom">
                                                            @if ($errors->any() && old('id') == $p->id_pelajar)
                                                                @php
                                                                    notifFailed($errors->all());
                                                                    $nama = old('nama');
                                                                    // $nis = old('nis');
                                                                    $kelas = old('kelas');
                                                                    $alamat = old('alamat');
                                                                    $telp = old('telp');
                                                                    $jk = old('jk');
                                                                @endphp
                                                            @else
                                                                @php
                                                                    $nama = $p->nama;
                                                                    // $nis = $p->nis;
                                                                    $kelas = $p->kelas;
                                                                    $alamat = $p->alamat;
                                                                    $telp = $p->telp;
                                                                    $jk = $p->jk;
                                                                @endphp
                                                            @endif
                                                            <input type="hidden" name="id"
                                                                value="{{ $p->id_pelajar }}">
                                                            {{-- <x-input :name="'nis'" :label="'NIS'" :val="$nis"
                                                                :req="'required'" :type="'number'" /> --}}
                                                            <x-input :name="'nama'" :label="'Nama lengkap'" :val="$nama"
                                                                :req="'required'" />
                                                            @php
                                                                // inputText('nis', 'NIS', $nis);
                                                                // inputText('nama', 'Nama lengkap', $nama);
                                                                inputText('kelas', 'Kelas ', $kelas);
                                                                inputText('telp', 'Nomor telepon', $telp, 'number', 10, 15);
                                                                inputText('alamat', 'Alamat', $alamat);
                                                            @endphp
                                                            <h6>Jenis kelamin</h6>
                                                            @php
                                                                inputRadio('jk', 'Laki-laki', 'L', $jk);
                                                                inputRadio('jk', 'Perempuan', 'P', $jk);
                                                            @endphp
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="reset" class="btn btn-secondary">Reset</button>
                                                            <button type="Submit" class="btn btn-primary">Update</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                        <form action="/pelajar/{{ $p->id_pelajar }}" method="post" class="d-inline">
                                            @method('delete')
                                            @csrf
                                            <button title="Hapus data" class="btn btn-danger show_confirm"><i
                                                    class="bi bi-trash-fill"></i></button>
                                        </form>
                                    </td>
                                    {{-- @endcan --}}
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
