@extends('home/layout/layout')

@section('main')
    <!-- Modal Body -->
    <!-- if you want to close by clicking outside the modal, delete the last endpoint:data-bs-backdrop and data-bs-keyboard -->
    <div class="modal fade" id="print" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false" role="dialog"
        aria-labelledby="modalTitleId" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable modal-lg my-3" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitleId">Laporan</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="/pembayaran-private/print" method="post" target="_blank">
                    @csrf
                    <div class="modal-body">
                        @php
                            inputText('awal', 'Tanggal awal', '', 'date', '');
                            inputText('akhir', 'Tanggal akhir', '', 'date', '');
                        @endphp
                    </div>
                    <div class="modal-footer">
                        <button type="reset" class="btn btn-secondary">Reset</button>
                        <button type="submit" class="btn btn-primary">Print</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="row pasLayar">
        <div class="col-12">
            <div class="card shadow-sm">
                {{-- <div class="card-header text-center  pt-3">
                    <h4 id="cekk">Tabel data</h4>
                </div> --}}
                <div class="card-body table-responsive">
                    @if (session()->has('pesan'))
                        <x-notif :pesan="session('pesan')" />
                    @endif
                    {{-- <a class="btn btn-primary mb-3" title="Tambah data" href="/pembayaran-private/create" role="button"><i
                            class="bi bi-bookmark-plus"></i> Tambah</a> --}}
                    <!-- Modal trigger button -->
                    <div class="mb-3">
                        {{-- @if (auth()->user()->status == 'admin' || auth()->user()->status == 'staff keuangan') --}}
                        <button type="button" class="btn btn-primary me-2" title="Tambah data" data-bs-toggle="modal"
                            data-bs-target="#new">
                            <i class="bi bi-bookmark-plus"></i> Tambah
                        </button>
                        <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#print"
                            title="Cetak laporan">
                            <i class="bi bi-printer-fill"></i> Print
                        </button>
                        {{-- @endif --}}
                    </div>

                    {{-- tambah data --}}
                    <div class="modal fade" id="new" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false"
                        role="dialog" aria-labelledby="modalTitleId" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-scrollable modal-lg my-3" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="modalTitleId">Tambah data</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <form action="/pembayaran-private" method="post">
                                    @csrf
                                    <div class="modal-body modalCustom">
                                        @if ($errors->any() && !old('id'))
                                            @php
                                                notifFailed($errors->all());
                                                $tgl_bayar = old('tgl_bayar');
                                                // $no_kwitansi = old('no_kwitansi');
                                                $jumlah_pertemuan = old('jumlah_pertemuan');
                                                $id_bimbel_private = old('id_bimbel_private');
                                                $id_pelajar = old('id_pelajar');
                                            @endphp
                                        @else
                                            @php
                                                $tgl_bayar = '';
                                                // $no_kwitansi = '';
                                                $jumlah_pertemuan = '';
                                                $id_bimbel_private = '';
                                                $id_pelajar = '';
                                            @endphp
                                        @endif

                                        @php
                                            inputText('tgl_bayar', 'Tanggal pembayaran', $tgl_bayar, 'date');
                                            // inputText('no_kwitansi', 'No. kwitansi', $no_kwitansi);
                                        @endphp
                                        <div class="form-floating mb-3">
                                            <select class="form-select" name="id_pelajar" id="id_pelajar"
                                                aria-label="Floating label select example">
                                                @foreach ($pelajar as $item)
                                                    <option {{ $id_pelajar == $item->id_pelajar ? 'selected' : '' }}
                                                        value="{{ $item->id_pelajar }}">
                                                        {{ 'Nama : ' . $item->nama . ' | Kelas : ' . $item->kelas }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            <label for="id_bimbel_private">Paket bimbel</label>
                                        </div>
                                        @php
                                            inputText('jumlah_pertemuan', 'Jumlah pertemuan', $jumlah_pertemuan, 'number');
                                        @endphp
                                        <div class="form-floating mb-3">
                                            <select class="form-select" name="id_bimbel_private" id="id_bimbel_private"
                                                aria-label="Floating label select example">
                                                @foreach ($private as $item)
                                                    <option
                                                        {{ $id_bimbel_private == $item->id_bimbel_private ? 'selected' : '' }}
                                                        value="{{ $item->id_bimbel_private }}">
                                                        {{ $item->paket_siswa . ' pelajar | sekolah ' . $item->tingkat_sekolah }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            <label for="id_bimbel_private">Paket bimbel</label>
                                        </div>

                                    </div>
                                    <div class="modal-footer">
                                        <button type="reset" class="btn btn-secondary">Reset</button>
                                        <button type="Submit" class="btn btn-primary">Simpan</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <table id="cekTabel" class="table table-nowrap table-centered rounded table-bordered border-dark">
                        <thead class="bg-primary text-center">
                            <tr>
                                <th class="text-white ">No</th>
                                <th class="text-white">Tanggal</th>
                                <th class="text-white">Kwitansi</th>
                                <th class="text-white">Pelajar</th>
                                <th class="text-white">Biaya</th>
                                <th class="text-white">Pertemuan</th>
                                <th class="text-white">Pilihan</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($data as $p)
                                <tr>
                                    <td class="text-center">{{ $loop->iteration }}</td>
                                    <td class="text-center">{{ tanggal($p->tgl_bayar) }}</td>
                                    <td>{{ $p->no_kwitansi }}</td>
                                    <td>{{ $p->pelajar->nama }} </td>
                                    <td class="text-end">
                                        {{ rupiah(($p->private->biaya / $p->private->jumlah_pertemuan) * $p->jumlah_pertemuan) }}
                                    </td>
                                    <td class="text-center">{{ $p->jumlah_pertemuan }} x</td>
                                    <td>
                                        {{-- <a href="/pembayaran-private/{{ $p->id_bayar_private }}/edit" title="Edit data"
                                            class="btn btn-warning "><i class="bi bi-pencil-square"></i></a> --}}
                                        {{-- @if (auth()->user()->status == 'admin' || auth()->user()->status == 'staff keuangan') --}}
                                        <button type="button" class="btn btn-warning" title="Edit data"
                                            data-bs-toggle="modal" data-bs-target="#edit{{ $p->id_bayar_private }}">
                                            <i class="bi bi-pencil-square"></i>
                                        </button>
                                        {{-- edit --}}
                                        <div class="modal fade" id="edit{{ $p->id_bayar_private }}" tabindex="-1"
                                            data-bs-backdrop="static" data-bs-keyboard="false" role="dialog"
                                            aria-labelledby="modalTitleId" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-scrollable modal-lg my-3"
                                                role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="modalTitleId">Edit data</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <form action="/pembayaran-private/{{ $p->id_bayar_private }}"
                                                        method="post">
                                                        @method('put')
                                                        @csrf
                                                        <div class="modal-body modalCustom">
                                                            <input type="hidden" name="id"
                                                                value="{{ $p->id_bayar_private }}">
                                                            @if ($errors->any() && old('id') == $p->id_bayar_private)
                                                                @php
                                                                    notifFailed($errors->all());
                                                                    $tgl_bayar = old('tgl_bayar');
                                                                    // $no_kwitansi = old('no_kwitansi');
                                                                    $jumlah_pertemuan = old('jumlah_pertemuan');
                                                                    $id_bimbel_private = old('id_bimbel_private');
                                                                    $id_pelajar = old('id_pelajar');
                                                                @endphp
                                                            @else
                                                                @php
                                                                    $tgl_bayar = $p->tgl_bayar;
                                                                    // $no_kwitansi = $p->no_kwitansi;
                                                                    $jumlah_pertemuan = $p->jumlah_pertemuan;
                                                                    $id_bimbel_private = $p->id_bimbel_private;
                                                                    $id_pelajar = $p->id_pelajar;
                                                                @endphp
                                                            @endif

                                                            @php
                                                                inputText('tgl_bayar', 'Tanggal pembayaran', $tgl_bayar, 'date');
                                                                // inputText('no_kwitansi', 'No. kwitansi', $no_kwitansi);
                                                            @endphp
                                                            <div class="form-floating mb-3">
                                                                <select class="form-select" name="id_pelajar"
                                                                    id="id_pelajar"
                                                                    aria-label="Floating label select example">
                                                                    @foreach ($pelajar as $item)
                                                                        <option
                                                                            {{ $id_pelajar == $item->id_pelajar ? 'selected' : '' }}
                                                                            value="{{ $item->id_pelajar }}">
                                                                            {{ 'Nama : ' . $item->nama . ' | Kelas : ' . $item->kelas }}
                                                                        </option>
                                                                    @endforeach
                                                                </select>
                                                                <label for="id_bimbel_private">Paket bimbel</label>
                                                            </div>
                                                            @php
                                                                inputText('jumlah_pertemuan', 'Jumlah pertemuan', $jumlah_pertemuan, 'number');
                                                            @endphp
                                                            <div class="form-floating mb-3">
                                                                <select class="form-select" name="id_bimbel_private"
                                                                    id="id_bimbel_private"
                                                                    aria-label="Floating label select example">
                                                                    @foreach ($private as $item)
                                                                        <option
                                                                            {{ $id_bimbel_private == $item->id_bimbel_private ? 'selected' : '' }}
                                                                            value="{{ $item->id_bimbel_private }}">
                                                                            {{ $item->paket_siswa . ' pelajar | sekolah ' . $item->tingkat_sekolah }}
                                                                        </option>
                                                                    @endforeach
                                                                </select>
                                                                <label for="id_bimbel_private">Paket bimbel</label>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="reset"
                                                                class="btn btn-secondary">Reset</button>
                                                            <button type="Submit" class="btn btn-primary">Update</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <form action="/pembayaran-private/{{ $p->id_bayar_private }}" method="post"
                                            class="d-inline">
                                            @method('delete')
                                            @csrf
                                            <button title="Hapus data" class="btn btn-danger show_confirm"><i
                                                    class="bi bi-trash-fill"></i></button>
                                        </form>
                                        <a href="/pembayaran-private/kwitansi/{{ $p->id_bayar_private }}" target="_blank"
                                            class="btn btn-success" title="Cetak kwitansi"><i
                                                class="bi bi-file-earmark-text-fill"></i></a>
                                        {{-- @endif --}}
                                        <a href="/pembayaran-private/pertemuan/{{ $p->id_bayar_private }}"
                                            title="Pertemuan bimbel" class="btn btn-info "><i
                                                class="bi bi-card-checklist"></i></a>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
