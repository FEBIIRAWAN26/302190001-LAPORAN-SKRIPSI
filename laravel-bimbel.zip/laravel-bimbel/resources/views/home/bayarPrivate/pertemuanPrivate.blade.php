@extends('home/layout/layout')

@section('main')
    <div class="row pasLayar">
        <div class="col-12">
            <div class="card shadow-sm">
                <div class="card-header text-center  pt-3">
                    <h4 id="cekk">Tabel data kehadiran bimbel private</h4>
                </div>
                <div class="card-body table-responsive">
                    @if (session()->has('pesan'))
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            <b><i class="bi bi-check-lg"></i></b> {{ session('pesan') }}
                        </div>
                    @endif
                    <div class="row">
                        <div class="col-2">NIS</div>
                        <div class="col-4">: {{ $data->pelajar->nis }}</div>
                        <div class="col-2">Jumlah pertemuan</div>
                        <div class="col-4">: {{ $data->jumlah_pertemuan }}</div>
                        <div class="col-2">Nama</div>
                        <div class="col-4">: {{ $data->pelajar->nama }}</div>
                        <div class="col-2">Alamat</div>
                        <div class="col-4">: {{ $data->pelajar->alamat }}</div>
                        <div class="col-2">Kelas</div>
                        <div class="col-4">: {{ $data->pelajar->kelas }}</div>

                        <div class="col-2">No. Telp</div>
                        <div class="col-4">: {{ $data->pelajar->telp }}</div>
                    </div>
                    <div class="my-3">
                        @if ($data->jumlah_pertemuan <= count($pertemuan))
                            <div class="alert alert-warning alert-dismissible fade show" id="notif" role="alert">
                                <b><i class="bi bi-exclamation-triangle-fill"></i></b> Sudah memenuhi jumlah pertemuan
                            </div>
                        @else
                            {{-- <a class="btn btn-primary" title="Tambah pertemuan"
                                href="/pembayaran-private/pertemuan/{{ $data->id_bayar_private }}/store" role="button"><i
                                    class="bi bi-bookmark-plus"></i> Tambah</a> --}}
                            {{-- @if (auth()->user()->status == 'admin' || auth()->user()->status == 'staff keuangan') --}}
                            <button type="button" id="btnAdd" class="btn btn-primary" title="Tambah pertemuan"
                                onclick="onAdd('<?= $data->id_bayar_private ?>')"><i class="bi bi-bookmark-plus"></i>
                                Tambah</button>
                            {{-- @endif --}}
                        @endif
                        {{-- <button onclick="cek()">cek</button> --}}
                    </div>
                    <table id="tabelPertemuan" class="table table-nowrap table-centered rounded table-bordered border-dark">
                        <thead class="bg-primary">
                            <tr>
                                <th class="text-white">No</th>
                                <th class="text-white">Tanggal</th>
                                {{-- @if (auth()->user()->status == 'admin' || auth()->user()->status == 'staff keuangan') --}}
                                <th class="text-white">Pilihan</th>
                                {{-- @endif --}}
                            </tr>
                        </thead>
                        <tbody id="isiPertemuan">
                            @foreach ($pertemuan as $p)
                                <tr>
                                    <td class="text-center">{{ $loop->iteration }}</td>
                                    <td class="text-center">{{ tanggal($p->tgl) }}</td>
                                    {{-- @if (auth()->user()->status == 'admin' || auth()->user()->status == 'staff keuangan') --}}
                                    <td>
                                        <button type="button" title="Hapus data"
                                            onclick="onDelete(this,'<?= $data->id_bayar_private ?>','<?= $p->id_pertemuan ?>')"
                                            class="btn btn-danger"><i class="bi bi-trash-fill"></i></button>
                                    </td>
                                    {{-- @endif --}}
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    {{-- <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> --}}
@endsection
@section('js-custom')
    <script>
        const jumlahPertemuan = <?= $data->jumlah_pertemuan ?>;

        function onDelete(par, id, del) {
            console.log('cekkk')
            Swal.fire({
                title: 'Yakin hapus data ?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $('button.btn-danger').html('tunggu').attr('disabled', 'disabled')
                    console.log(id, del);
                    $(par).closest('tr').remove()
                    if (result.isConfirmed) {
                        $.ajax({
                            url: '/pembayaran-private/pertemuan/' + id,
                            type: 'DELETE',
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                            },
                            data: {
                                id_pertemuan: del
                            },
                            success: function(response) {
                                console.log(response);
                                location.reload()
                            },
                            error: function(xhr, status, error) {
                                console.log('Terjadi kesalahan saat menghapus data:', error);
                            },
                            complete: function() {}
                        })
                    }
                }
            })
        }

        function cek() {
            var tbody = $('tbody#isiPertemuan')
            tbody.empty()
            location.reload()
        }

        function onAdd(id) {
            Swal.fire({
                title: 'Tambah data ?',
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes'
            }).then((result) => {
                if (result.isConfirmed) {
                    $('button.btn-primary').html('tunggu')
                    $('button.btn-primary').prop('disabled', true)
                    console.log(id)
                    $.ajax({
                        url: '/pembayaran-private/pertemuan/' + id + '/store',
                        type: 'get',
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        success: function(response) {
                            console.log(response)
                            location.reload()
                            // var isiTabel = $('tbody#isiPertemuan')
                            // // isiTabel.empty()
                            // var pertemuan = 0
                            // $.each(response.data, function(index, item) {
                            //     const tr = $('<tr>')
                            //     const td = $('<td>')
                            //     const del = $('<button></button>', {
                            //         type: 'button',
                            //         title: 'Hapus data',
                            //         onclick: 'onDelete(this, ' + item.id_bayar + ', ' + item
                            //             .id_pertemuan + ')',
                            //         class: 'btn btn-danger'
                            //     }).append('<i class="bi bi-trash-fill"></i>')

                            //     const col1 = td.clone().append(index + 1)
                            //     const col2 = td.clone().append(item.tgl)
                            //     const col3 = td.clone().append(del)
                            //     tr.append(col1.clone(), col2.clone(), col3.clone())
                            //     isiTabel.append(tr)
                            //     pertemuan += 1
                            //     console.log(item)
                            // });
                            // // location.reload()
                            // if (pertemuan >= jumlahPertemuan) {
                            //     $('#notif').show();
                            //     $('#btnAdd').hide();
                            // } else {
                            //     $('#notif').hide();
                            //     $('#btnAdd').show(

                            //     );
                            // }
                        },
                        error: function(xhr, status, error) {
                            console.log('Terjadi kesalahan saat menambah data:', error);
                        },
                        complete: function() {}
                    })
                }
            })
        }

        $(document).ready(function() {
            $('#tabelPertemuan').DataTable({
                searching: false,
            });
        });
    </script>
@endsection
