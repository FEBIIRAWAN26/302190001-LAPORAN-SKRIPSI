<x-headerPrint title="{{ $title }}" />

<div class="container">
    <header class="pb-3 position-relative">
        <img src="/img/blc-logo.png" width="75px" alt="Logo BLC" class="position-absolute">
        <h2 class="text-center pt-4">Data Pembayaran Bimbel Private</h2>
    </header>
    <div class="border-top border-2 border-dark mb-4"></div>
    <main>
        <table class="table table-bordered border-dark">
            <thead class="bg-secondary text-white">
                <tr>
                    <th>No </th>
                    <th>Tanggal</th>
                    <th>Kwitansi</th>
                    <th>Pelajar</th>
                    <th>Biaya</th>
                    <th>Pertemuan</th>
                </tr>
            </thead>
            <tbody>
                @php
                    $jml = 0;
                @endphp
                @foreach ($data as $item)
                    <tr>
                        <td class="text-center">{{ $loop->iteration }}</td>
                        <td class="text-center">{{ tanggal($item->tgl_bayar) }}</td>
                        <td class="text-center">{{ $item->no_kwitansi }}</td>
                        <td>{{ $item->pelajar->nama }}</td>
                        <td class="text-end">
                            {{ rupiah($bayar = ($item->private->biaya / $item->private->jumlah_pertemuan) * $item->jumlah_pertemuan) }}
                        </td>
                        <td class="text-end">{{ $item->jumlah_pertemuan . ' x' }}</td>
                    </tr>
                    @php
                        $jml += $bayar;
                    @endphp
                @endforeach
                <tr>
                    <th></th>
                    <th colspan="3">Total</th>
                    <th class="text-end">{{ rupiah($jml) }}</th>
                    <th></th>
                </tr>
            </tbody>
        </table>

    </main>
</div>
<x-footerPrint />
