<x-headerPrint title="{{ $title }}" />
<style>
    .bg-gambar {
        background-image: url(/img/bg-logo.png);
        /* Ganti dengan path ke logo Anda */
        background-size: contain;
        background-repeat: no-repeat;
        background-position: center;
        /* Transparansi 50% (0.5) */
        padding: 20px;
    }

    .text-12 {
        font-size: 12px;
    }
</style>
<div class="container">
    <div class="border border-1 border-dark mt-2 wadah">
        <header class="position-relative">
            <img src="/img/blc-logo.png" width="75px" alt="Logo BLC" class="position-absolute logo-30">
            <div class="position-absolute end-0 top-3">
                <main>
                    <table class="teble table-bordered">
                        <tr>
                            <td><b>BUKTI PEMBAYARAN</b></td>
                        </tr>
                        <tr>
                            <td class="text-center"> No. Kwitansi</td>
                        </tr>
                        <tr>
                            <td class="text-center">{{ $data->no_kwitansi }}</td>
                        </tr>
                    </table>
                </main>
            </div>
            <div class="text-center p-0">
                <main>
                    <p class=" m-0">Bimbingan Belajar</p>
                </main>
                <h2 class=" m-0">BRILLIANT LEARNING CENTER</h2>
                <main>
                    <P class="text-sm-center m-0">
                        Jl. Cicukang Rt 02/28 Ds. Mekarrahayu Kec. Margaasih Kab. Bandung 40218<br> <i
                            class="bi bi-chat-dots-fill"></i> 0855721064363 <i class="bi bi-chat-left-dots-fill"></i>
                        D010ABB6
                        <i class="bi bi-chat-left-text-fill"></i> brilliant_blc <i class="bi bi-envelope-at-fill"></i>
                        brilliantblc2013@gmail.com<br>
                        <b>BNI : 0257636907 BRI : 399801009816537</b>
                    </P>
                </main>
            </div>
        </header>
        <div class="border-top border-2 border-dark"></div>
        <main class="bg-gambar py-0 m-0">
            <table>
                <tr>
                    <td width="30%" class="m-0"></td>
                    <td width="35%"></td>
                    <td width="15%">No. Record</td>
                    <td width="25%">: </td>
                </tr>
                <tr>
                    <td width="30%" class="m-0">NIS</td>
                    <td width="35%">: {{ $data->pelajar->nis }}</td>

                    <td>Kelas</td>
                    <td>: {{ $data->pelajar->kelas }}</td>
                </tr>
                <tr>
                    <td class="m-0">Nama</td>
                    <td>: {{ $data->pelajar->nama }}</td>

                    <td>Jenis pembayaran</td>
                    <td>: {{ $jenis }}</td>
                </tr>
                <tr>
                    <td class="m-0">Jumlah</td>
                    <td>:
                        {{ rupiah(($data->private->biaya / $data->private->jumlah_pertemuan) * $data->jumlah_pertemuan) }}
                    </td>
                </tr>
                <tr>
                    <td class="m-0">Terbilang</td>
                    <td colspan="3">:
                        {{ uangText(($data->private->biaya / $data->private->jumlah_pertemuan) * $data->jumlah_pertemuan) }}
                        rupiah</td>
                </tr>
                <tr>
                    <td>Keterangan</td>
                </tr>
                <tr>
                    <td colspan="2" class="m-0">
                        <p class="border-dark border py-4">.</p>
                    </td>
                    <td colspan="2" class="text-center">Tanggal : {{ date('d M Y') }}<br>Penerima</td>
                </tr>
                <tr>
                    <td colspan="2" class="m-0">
                        <p class="mt-3">Catatan :<br><i>*Biaya yang telah dibayar tidak dapat diambil
                                kembali</i></p>
                    </td>
                    <td colspan="2">
                        <p class="text-center" style="margin-top: 40px">
                            (................................................................)</p>
                    </td>
                </tr>
            </table>
        </main>
    </div>
</div>
<x-footerPrint />
