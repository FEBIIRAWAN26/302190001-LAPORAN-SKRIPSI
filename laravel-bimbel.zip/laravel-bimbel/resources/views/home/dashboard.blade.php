@extends('home.layout.layout')

@section('main')
    <style>
        table.table {
            text-align: center
        }
    </style>
    @if (session('non_active'))
        <div class="row">
            <div class="col-12">
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <i class="bi bi-info-circle-fill fs-4"></i> Konfirmasi akun yang belum di aktifkan yaitu bernama : <b>
                        @foreach (session('non_active') as $i)
                            {{ $i . ', ' }}
                        @endforeach
                    </b>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            </div>
        </div>
    @endif
    <div class="row">
        <div class="col-6 mb-4">
            <div class="card border-0 shadow">
                <div class="bg-warning card-header border-bottom">
                    <h5>Total Pembayaran Bimbel Reguler 5 Bulan terakhir</h5>
                </div>
                <div class="card-body">
                    <canvas id="grafikReguler"></canvas>
                </div>
            </div>
        </div>
        <div class="col-6 mb-4">
            <div class="card border-0 shadow">
                <div class="bg-info card-header border-bottom">
                    <h5>Total Pembayaran Bimbel Private 5 Bulan terakhir</h5>
                </div>
                <div class="card-body">
                    <canvas id="grafikPrivate"></canvas>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="row">
                <div class="col-6 col-xxl-6 mb-4">
                    <div class="card border-0 shadow">
                        <div class="bg-warning card-header border-bottom">
                            <h5>Transaksi reguler terbaru</h5>
                        </div>
                        <div class="card-body">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Tanggal</th>
                                        <th>No. kwitansi</th>
                                        <th>Pelajar</th>
                                        <th>Bayar</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($reguler as $item)
                                        <tr>
                                            <td>{{ $loop->iteration }}</td>
                                            <td>{{ tanggal($item->tgl_bayar) }}</td>
                                            <td>{{ $item->no_kwitansi }}</td>
                                            <td>{{ $item->pelajar->nama }}</td>
                                            <td class="text-end">{{ rupiah($item->reguler->biaya) }}</td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-xxl-6 mb-4">
                    <div class="card border-0 shadow">
                        <div class="bg-info card-header border-bottom">
                            <h5>Transaksi private terbaru</h5>
                        </div>
                        <div class="card-body">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Tanggal</th>
                                        <th>No. kwitansi</th>
                                        <th>Pelajar</th>
                                        <th>Bayar</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($private as $item)
                                        <tr>
                                            <td>{{ $loop->iteration }}</td>
                                            <td>{{ tanggal($item->tgl_bayar) }}</td>
                                            <td>{{ $item->no_kwitansi }}</td>
                                            <td>{{ $item->pelajar->nama }}</td>
                                            <td class="text-end">
                                                {{ rupiah(($item->private->biaya / $item->private->jumlah_pertemuan) * $item->jumlah_pertemuan) }}
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('js-custom')
    <script>
        const bayarReguler = <?= json_encode($bayarReguler) ?>;
        const bayarPrivate = <?= json_encode($bayarPrivate) ?>;
        grafik(bayarReguler, 'grafikReguler')
        grafik(bayarPrivate, 'grafikPrivate', 'brown')

        function grafik(arr = [], id = '', warna = 'green') {
            var labels = []
            var data = []
            $.each(arr, function(i, item) {
                labels.push(item['bulan'])
                data.push(item['totalPembayaran'])
            })

            const ctx = $('#' + id)
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Total pembayaran Rp. ',
                        data: data,
                        borderWidth: 1,
                        backgroundColor: warna,
                        borderColor: 'gray',
                        pointRadius: 5
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    },
                    plugins: {
                        legend: {
                            display: false // Menghilangkan tampilan legend (header)
                        }
                    },
                }
            });
        }
    </script>
@endsection
