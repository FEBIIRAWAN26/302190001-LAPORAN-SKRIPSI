@extends('home.layout.layout')

@section('main')
    <div class="row">
        <div class="col-12">
            <div class="card shadow-sm">
                {{-- <div class="card-header text-center  pt-3">
                    <h4 id="cekk">Tabel data</h4>
                </div> --}}
                <div class="card-body table-responsive">
                    @if (session()->has('gagal'))
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            <b><i class="bi bi-exclamation-triangle-fill"></i></b> {{ session('gagal') }}
                        </div>
                    @endif
                    @if (session()->has('pesan'))
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            <b><i class="bi bi-check-lg"></i></b> {{ session('pesan') }}
                        </div>
                    @endif
                    <!-- Modal trigger button -->
                    <button type="button" class="btn btn-primary mb-3" title="Tambah data" data-bs-toggle="modal"
                        data-bs-target="#new">
                        <i class="bi bi-bookmark-plus"></i> Tambah
                    </button>
                    {{-- tambah data --}}
                    <div class="modal fade" id="new" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false"
                        role="dialog" aria-labelledby="modalTitleId" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-scrollable modal-lg my-3" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="modalTitleId">Tambah data</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <form action="/pengguna" method="post">
                                    @csrf
                                    <div class="modal-body modalCustom">
                                        @if ($errors->any() && !old('id'))
                                            @php
                                                notifFailed($errors->all());
                                                $nama = old('nama');
                                                $username = old('username');
                                                $telp = old('telp');
                                                $status = old('status');
                                                $password = old('password');
                                                $is_active = old('is_active');
                                            @endphp
                                        @else
                                            @php
                                                $nama = '';
                                                $username = '';
                                                $telp = '';
                                                $status = '';
                                                $password = '';
                                                $is_active = '';
                                            @endphp
                                        @endif
                                        @php
                                            inputText('nama', 'Nama lengkap', $nama);
                                            inputText('username', 'Username', $username);
                                            inputText('password', 'Password', $password);
                                            inputText('telp', 'Nomor telepon', $telp, 'number');
                                        @endphp
                                        <h6>Status pengguna</h6>
                                        @php
                                            inputRadio('status', 'Admin', 'admin', $status);
                                            inputRadio('status', 'Owner', 'owner', $status);
                                            inputRadio('status', 'Manajer', 'manajer', $status);
                                        @endphp
                                        @if (auth()->user()->status == 'owner')
                                            <hr>
                                            <h6>Is Active</h6>
                                            @php
                                                inputRadio('is_active', 'Active', 0, $is_active);
                                                inputRadio('is_active', 'Non active', 1, $is_active);
                                            @endphp
                                        @endif
                                    </div>
                                    <div class="modal-footer">
                                        <button type="reset" class="btn btn-secondary">Reset</button>
                                        <button type="Submit" class="btn btn-primary">Simpan</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>


                    <!-- Optional: Place to the bottom of scripts -->
                    <script>
                        const myModal = new bootstrap.Modal(document.getElementById('modalId'), options)
                    </script>
                    <table id="cekTabel" class="table table-nowrap table-centered rounded table-bordered border-dark">
                        <thead class="bg-primary">
                            <tr>
                                <th class="text-white">No</th>
                                <th class="text-white">Nama</th>
                                <th class="text-white">Username</th>
                                <th class="text-white">Password</th>
                                <th class="text-white">Telepon</th>
                                <th class="text-white">Status</th>
                                <th class="text-white">Is Active</th>
                                <th class="text-white">Pilihan</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($pengguna as $p)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>{{ $p->nama }}</td>
                                    <td>{{ $p->username }}</td>
                                    <td>{{ $p->password2 }}</td>
                                    <td>{{ $p->telp }}</td>
                                    <td>{{ $p->status }}</td>
                                    <td>{{ $p->is_active == 1 ? 'Active' : 'Non active' }}</td>
                                    <td>
                                        <!-- <a href="/pengguna/{{ $p->id_user }}/edit" title="Edit data"
                                                                                                                                                                                                                                class="btn btn-warning "></a> -->
                                        <button type="button" class="btn btn-warning me-2" data-bs-toggle="modal"
                                            data-bs-target="#edit{{ $p->id_user }}">
                                            <i class="bi bi-pencil-square"></i>
                                        </button>
                                        {{-- edit --}}
                                        <div class="modal fade" id="edit{{ $p->id_user }}" tabindex="-1"
                                            data-bs-backdrop="static" data-bs-keyboard="false" role="dialog"
                                            aria-labelledby="modalTitleId" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-scrollable modal-lg my-3" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="modalTitleId">Edit data</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <form action="/pengguna/{{ $p->id_user }}" method="post">
                                                        @method('put')
                                                        @csrf
                                                        <div class="modal-body modalCustom">
                                                            @if ($errors->any() && old('id') == $p->id_user)
                                                                @php
                                                                    notifFailed($errors->all());
                                                                    $nama = old('nama');
                                                                    $username = old('username');
                                                                    $telp = old('telp');
                                                                    $status = old('status');
                                                                    $password = old('password');
                                                                    $is_active = old('is_active');
                                                                @endphp
                                                            @else
                                                                @php
                                                                    $nama = $p->nama;
                                                                    $username = $p->username;
                                                                    $telp = $p->telp;
                                                                    $status = $p->status;
                                                                    $is_active = $p->is_active;
                                                                    $password = $p->password2;
                                                                @endphp
                                                            @endif
                                                            <input type="hidden" name="id"
                                                                value="{{ $p->id_user }}">
                                                            @php
                                                                inputText('nama', 'Nama lengkap', $nama);
                                                                inputText('username', 'Username', $username);
                                                                inputText('password', 'Password', $password);
                                                                inputText('telp', 'Nomor telepon', $telp, 'number');
                                                            @endphp
                                                            <h6>Status pengguna</h6>
                                                            @php
                                                                inputRadio('status', 'Admin', 'admin', $status);
                                                                inputRadio('status', 'Owner', 'owner', $status);
                                                                inputRadio('status', 'Manajer', 'manajer', $status);
                                                            @endphp
                                                            @if (auth()->user()->status == 'owner')
                                                                <hr>
                                                                <h6>Is Active</h6>
                                                                @php
                                                                    inputRadio('is_active', 'Active', 1, $is_active);
                                                                    inputRadio('is_active', 'Non active', 0, $is_active);
                                                                @endphp
                                                            @endif
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="reset" class="btn btn-secondary">Reset</button>
                                                            <button type="Submit" class="btn btn-primary">Update</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                        <form action="/pengguna/{{ $p->id_user }}" method="post" class="d-inline">
                                            @method('delete')
                                            @csrf
                                            <button title="Hapus data" class="btn btn-danger show_confirm"><i
                                                    class="bi bi-trash-fill"></i></button>
                                        </form>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
