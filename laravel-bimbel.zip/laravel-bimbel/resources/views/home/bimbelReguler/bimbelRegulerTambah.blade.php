@extends('home/layout/layout')

@section('main')
    <div class="row pasLayar">
        <div class="col-12">
            <div class="card shadow-sm">
                <div class="card-header text-center pt-3">
                    <h4>Form tambah data bimbel reguler</h4>
                </div>
                <form action="/bimbel-reguler" method="POST">
                    <div class="card-body">
                        @csrf
                        <div class="form-floating mb-3">
                            <input type="text" name="kelas" placeholder="Kelas" minlength="1" maxlength="5" autofocus
                                required
                                class="form-control @error('kelas') is-invalid
                            @enderror"
                                id="kelas"value="{{ old('kelas') }}">
                            <label for="kelas">Kelas</label>
                            @error('kelas')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-floating mb-3">
                            <input type="number" name="biaya" placeholder="Biaya" required min="1"
                                class="form-control @error('biaya') is-invalid
                            @enderror"
                                id="biaya"value="{{ old('biaya') }}">
                            <label for="biaya">Biaya</label>
                            @error('biaya')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-floating mb-3">
                            <input type="number" name="jumlah_pertemuan" placeholder="Jumlah Pertemuan" min="1"
                                required
                                class="form-control @error('jumlah_pertemuan') is-invalid
                            @enderror"
                                id="jumlah_pertemuan"value="{{ old('jumlah_pertemuan') }}">
                            <label for="jumlah_pertemuan">Jumlah Pertemuan</label>
                            @error('jumlah_pertemuan')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>
                    <div class="card-footer">
                        <div class="mb-3">
                            <button class="btn btn-primary me-2" type="submit">Simpan</button>
                            <button class="btn btn-secondary" type="reset">Reset</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
